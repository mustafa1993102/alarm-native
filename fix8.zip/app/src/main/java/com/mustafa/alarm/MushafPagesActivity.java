package com.mustafa.alarm;

import android.app.Activity;
import android.content.SharedPreferences;
import android.content.res.AssetManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager2.widget.ViewPager2;
import java.io.IOException;
import java.io.InputStream;

/**
 * يعرض صور صفحات المصحف الأصلية كما هي (بلا أي إعادة ترتيب للنص)،
 * بتقليب حقيقي بين الصفحات. الصور مرفقة داخل التطبيق نفسه (assets)، فتعمل بلا إنترنت.
 */
public class MushafPagesActivity extends Activity {
    static final int BG = 0xFF0E1428, TXT = 0xFFEEF1FB, MUTED = 0xFF8992BE;
    static final String DIR = "quran_pages";
    static final String PREFIX = "pg-";

    ViewPager2 pager;
    TextView label;
    SharedPreferences sp;
    String[] files;

    int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        sp = getSharedPreferences("mushafpages", 0);

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(BG);
        root.setFitsSystemWindows(true);

        TextView loading = new TextView(this);
        loading.setText("جارٍ فتح صفحات المصحف...");
        loading.setTextColor(MUTED);
        loading.setGravity(Gravity.CENTER);
        root.addView(loading, new FrameLayout.LayoutParams(-1, -2, Gravity.CENTER));

        pager = new ViewPager2(this);
        pager.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        root.addView(pager, new FrameLayout.LayoutParams(-1, -1));

        FrameLayout top = new FrameLayout(this);
        top.setBackgroundColor(0xCC0E1428);
        TextView back = new TextView(this);
        back.setText("✕");
        back.setTextSize(20);
        back.setTextColor(TXT);
        back.setPadding(dp(14), dp(10), dp(14), dp(10));
        back.setOnClickListener(v -> finish());
        top.addView(back, new FrameLayout.LayoutParams(-2, -2, Gravity.END | Gravity.CENTER_VERTICAL));

        label = new TextView(this);
        label.setTextColor(TXT);
        label.setTextSize(13);
        label.setGravity(Gravity.CENTER);
        label.setPadding(dp(50), dp(12), dp(50), dp(12));
        top.addView(label, new FrameLayout.LayoutParams(-1, -2));

        TextView mark = new TextView(this);
        mark.setText("🔖");
        mark.setTextSize(20);
        mark.setPadding(dp(14), dp(10), dp(14), dp(10));
        mark.setOnClickListener(v -> {
            sp.edit().putInt("lastPage", pager.getCurrentItem()).apply();
            Toast.makeText(this, "تم حفظ موضع التوقف", Toast.LENGTH_SHORT).show();
        });
        top.addView(mark, new FrameLayout.LayoutParams(-2, -2, Gravity.START | Gravity.CENTER_VERTICAL));

        root.addView(top, new FrameLayout.LayoutParams(-1, -2, Gravity.TOP));
        setContentView(root);

        try {
            AssetManager am = getAssets();
            String[] raw = am.list(DIR);
            java.util.List<String> onlyPages = new java.util.ArrayList<>();
            if (raw != null) {
                for (String f : raw) if (f.startsWith(PREFIX) && f.endsWith(".jpg")) onlyPages.add(f);
            }
            java.util.Collections.sort(onlyPages);
            files = onlyPages.toArray(new String[0]);
        } catch (IOException e) {
            files = new String[0];
        }

        if (files.length == 0) {
            loading.setText("لم يتم العثور على صفحات المصحف داخل التطبيق");
            return;
        }
        loading.setVisibility(View.GONE);

        pager.setAdapter(new Adapter());
        pager.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
            @Override public void onPageSelected(int pos) {
                label.setText("صفحة " + (pos + 1) + " / " + files.length);
                sp.edit().putInt("lastPage", pos).apply();
            }
        });
        int start = getIntent().getIntExtra("page", sp.getInt("lastPage", 0));
        pager.setCurrentItem(Math.min(Math.max(start, 0), files.length - 1), false);
        label.setText("صفحة " + (pager.getCurrentItem() + 1) + " / " + files.length);
    }

    class Adapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
        @NonNull @Override
        public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            ImageView iv = new ImageView(parent.getContext());
            iv.setLayoutParams(new FrameLayout.LayoutParams(-1, -1));
            iv.setAdjustViewBounds(true);
            iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
            FrameLayout fl = new FrameLayout(parent.getContext());
            fl.setLayoutParams(new ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            fl.setBackgroundColor(0xFFFFFFFF);
            fl.addView(iv);
            return new RecyclerView.ViewHolder(fl) {};
        }

        @Override
        public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
            ImageView iv = (ImageView) ((FrameLayout) holder.itemView).getChildAt(0);
            iv.setImageBitmap(null);
            try {
                DisplayMetrics dm = getResources().getDisplayMetrics();
                InputStream is1 = getAssets().open(DIR + "/" + files[position]);
                BitmapFactory.Options opts = new BitmapFactory.Options();
                opts.inJustDecodeBounds = true;
                BitmapFactory.decodeStream(is1, null, opts);
                is1.close();
                int sample = 1;
                while (opts.outWidth / (sample * 2) >= dm.widthPixels) sample *= 2;
                BitmapFactory.Options opts2 = new BitmapFactory.Options();
                opts2.inSampleSize = sample;
                InputStream is2 = getAssets().open(DIR + "/" + files[position]);
                Bitmap bmp = BitmapFactory.decodeStream(is2, null, opts2);
                is2.close();
                iv.setImageBitmap(bmp);
            } catch (Exception e) {
                iv.setImageBitmap(null);
            }
        }

        @Override public int getItemCount() { return files.length; }
    }
}
