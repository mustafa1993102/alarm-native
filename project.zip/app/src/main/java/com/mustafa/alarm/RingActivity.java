package com.mustafa.alarm;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class RingActivity extends Activity {
    static RingActivity cur;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        cur = this;
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true);
            setTurnScreenOn(true);
        }
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
                | WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD);
        final int id = getIntent().getIntExtra("id", 0);

        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.VERTICAL);
        r.setGravity(Gravity.CENTER);
        r.setBackgroundColor(0xFF0E1428);
        r.setPadding(60, 60, 60, 60);
        r.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        TextView ico = new TextView(this);
        ico.setText("⏰");
        ico.setTextSize(72);
        ico.setGravity(Gravity.CENTER);
        r.addView(ico);

        TextView t = new TextView(this);
        t.setText(new SimpleDateFormat("h:mm a", new Locale("ar")).format(new Date()));
        t.setTextSize(52);
        t.setTextColor(0xFFEEF1FB);
        t.setGravity(Gravity.CENTER);
        r.addView(t);

        TextView l = new TextView(this);
        l.setText("المنبّه يرنّ الآن");
        l.setTextSize(16);
        l.setTextColor(0xFF8992BE);
        l.setGravity(Gravity.CENTER);
        l.setPadding(0, 10, 0, 60);
        r.addView(l);

        Button stop = mk("إيقاف", 0xFFF2685C, 0xFF2A0F0C);
        stop.setOnClickListener(v -> {
            startService(new Intent(this, RingService.class).setAction("STOP").putExtra("id", id));
            finish();
        });
        r.addView(stop, new LinearLayout.LayoutParams(-1, 170));

        Button snz = mk("غفوة 5 دقائق", 0xFF2C5850, 0xFF5FE3C4);
        snz.setOnClickListener(v -> {
            startService(new Intent(this, RingService.class).setAction("SNOOZE").putExtra("id", id));
            finish();
        });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, 150);
        lp.topMargin = 30;
        r.addView(snz, lp);

        setContentView(r);
    }

    Button mk(String s, int bg, int fg) {
        Button b = new Button(this);
        b.setText(s);
        b.setTextSize(20);
        b.setTextColor(fg);
        GradientDrawable g = new GradientDrawable();
        g.setColor(bg);
        g.setCornerRadius(40);
        b.setBackground(g);
        return b;
    }

    @Override
    protected void onDestroy() {
        if (cur == this) cur = null;
        super.onDestroy();
    }
}
