package com.mustafa.alarm;

import android.app.Activity;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.util.HashMap;
import java.util.Map;

public class AdhkarActivity extends Activity {
    static final int BG = 0xFF0E1428, CARD = 0xFF182047, TXT = 0xFFEEF1FB,
            MUTED = 0xFF8992BE, SUN = 0xFFF5A25C, MINT = 0xFF5FE3C4, BTN = 0xFF212A56;

    static final String[][] MORNING = {
        {"أَصْبَحْنَا وَأَصْبَحَ الْمُلْكُ لِلَّهِ، وَالْحَمْدُ لِلَّهِ، لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ، رَبِّ أَسْأَلُكَ خَيْرَ مَا فِي هَذَا الْيَوْمِ وَخَيْرَ مَا بَعْدَهُ، وَأَعُوذُ بِكَ مِنْ شَرِّ مَا فِي هَذَا الْيَوْمِ وَشَرِّ مَا بَعْدَهُ", "1"},
        {"اللَّهُمَّ بِكَ أَصْبَحْنَا، وَبِكَ أَمْسَيْنَا، وَبِكَ نَحْيَا، وَبِكَ نَمُوتُ، وَإِلَيْكَ النُّشُورُ", "1"},
        {"اللَّهُمَّ أَنْتَ رَبِّي لَا إِلَهَ إِلَّا أَنْتَ، خَلَقْتَنِي وَأَنَا عَبْدُكَ، وَأَنَا عَلَى عَهْدِكَ وَوَعْدِكَ مَا اسْتَطَعْتُ، أَعُوذُ بِكَ مِنْ شَرِّ مَا صَنَعْتُ، أَبُوءُ لَكَ بِنِعْمَتِكَ عَلَيَّ، وَأَبُوءُ بِذَنْبِي فَاغْفِرْ لِي فَإِنَّهُ لَا يَغْفِرُ الذُّنُوبَ إِلَّا أَنْتَ (سيّد الاستغفار)", "1"},
        {"اللَّهُمَّ عَافِنِي فِي بَدَنِي، اللَّهُمَّ عَافِنِي فِي سَمْعِي، اللَّهُمَّ عَافِنِي فِي بَصَرِي، لَا إِلَهَ إِلَّا أَنْتَ", "3"},
        {"اللَّهُمَّ إِنِّي أَعُوذُ بِكَ مِنَ الْكُفْرِ وَالْفَقْرِ، وَأَعُوذُ بِكَ مِنْ عَذَابِ الْقَبْرِ، لَا إِلَهَ إِلَّا أَنْتَ", "3"},
        {"حَسْبِيَ اللَّهُ لَا إِلَهَ إِلَّا هُوَ عَلَيْهِ تَوَكَّلْتُ وَهُوَ رَبُّ الْعَرْشِ الْعَظِيمِ", "7"},
        {"بِسْمِ اللَّهِ الَّذِي لَا يَضُرُّ مَعَ اسْمِهِ شَيْءٌ فِي الْأَرْضِ وَلَا فِي السَّمَاءِ وَهُوَ السَّمِيعُ الْعَلِيمُ", "3"},
        {"رَضِيتُ بِاللَّهِ رَبًّا، وَبِالْإِسْلَامِ دِينًا، وَبِمُحَمَّدٍ صَلَّى اللَّهُ عَلَيْهِ وَسَلَّمَ نَبِيًّا", "3"},
        {"سُبْحَانَ اللَّهِ وَبِحَمْدِهِ", "100"},
        {"لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ", "10"},
        {"أَسْتَغْفِرُ اللَّهَ وَأَتُوبُ إِلَيْهِ", "100"},
        {"اللَّهُمَّ صَلِّ وَسَلِّمْ عَلَى نَبِيِّنَا مُحَمَّدٍ", "10"},
    };

    static final String[][] EVENING = {
        {"أَمْسَيْنَا وَأَمْسَى الْمُلْكُ لِلَّهِ، وَالْحَمْدُ لِلَّهِ، لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ، رَبِّ أَسْأَلُكَ خَيْرَ مَا فِي هَذِهِ اللَّيْلَةِ وَخَيْرَ مَا بَعْدَهَا، وَأَعُوذُ بِكَ مِنْ شَرِّ مَا فِي هَذِهِ اللَّيْلَةِ وَشَرِّ مَا بَعْدَهَا", "1"},
        {"اللَّهُمَّ بِكَ أَمْسَيْنَا، وَبِكَ أَصْبَحْنَا، وَبِكَ نَحْيَا، وَبِكَ نَمُوتُ، وَإِلَيْكَ الْمَصِيرُ", "1"},
        {"اللَّهُمَّ أَنْتَ رَبِّي لَا إِلَهَ إِلَّا أَنْتَ، خَلَقْتَنِي وَأَنَا عَبْدُكَ، وَأَنَا عَلَى عَهْدِكَ وَوَعْدِكَ مَا اسْتَطَعْتُ، أَعُوذُ بِكَ مِنْ شَرِّ مَا صَنَعْتُ، أَبُوءُ لَكَ بِنِعْمَتِكَ عَلَيَّ، وَأَبُوءُ بِذَنْبِي فَاغْفِرْ لِي فَإِنَّهُ لَا يَغْفِرُ الذُّنُوبَ إِلَّا أَنْتَ (سيّد الاستغفار)", "1"},
        {"اللَّهُمَّ عَافِنِي فِي بَدَنِي، اللَّهُمَّ عَافِنِي فِي سَمْعِي، اللَّهُمَّ عَافِنِي فِي بَصَرِي، لَا إِلَهَ إِلَّا أَنْتَ", "3"},
        {"اللَّهُمَّ إِنِّي أَعُوذُ بِكَ مِنَ الْكُفْرِ وَالْفَقْرِ، وَأَعُوذُ بِكَ مِنْ عَذَابِ الْقَبْرِ، لَا إِلَهَ إِلَّا أَنْتَ", "3"},
        {"حَسْبِيَ اللَّهُ لَا إِلَهَ إِلَّا هُوَ عَلَيْهِ تَوَكَّلْتُ وَهُوَ رَبُّ الْعَرْشِ الْعَظِيمِ", "7"},
        {"أَعُوذُ بِكَلِمَاتِ اللَّهِ التَّامَّاتِ مِنْ شَرِّ مَا خَلَقَ", "3"},
        {"اللَّهُمَّ إِنِّي أَسْأَلُكَ الْعَفْوَ وَالْعَافِيَةَ فِي الدُّنْيَا وَالْآخِرَةِ", "1"},
        {"سُبْحَانَ اللَّهِ وَبِحَمْدِهِ", "100"},
        {"لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ", "10"},
        {"أَسْتَغْفِرُ اللَّهَ وَأَتُوبُ إِلَيْهِ", "100"},
        {"اللَّهُمَّ صَلِّ وَسَلِّمْ عَلَى نَبِيِّنَا مُحَمَّدٍ", "10"},
    };

    boolean morning = true;
    LinearLayout listBox;
    Map<Integer, Integer> progress = new HashMap<>();

    int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(BG);
        sv.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        sv.setFitsSystemWindows(true);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(22), dp(16), dp(30));

        TextView title = new TextView(this);
        title.setText("أذكار الصباح والمساء");
        title.setTextSize(22);
        title.setTypeface(null, Typeface.BOLD);
        title.setTextColor(TXT);
        title.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(-1, -2);
        tp.bottomMargin = dp(16);
        root.addView(title, tp);

        LinearLayout tabs = new LinearLayout(this);
        tabs.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        final Button mBtn = tabBtn("☀️ الصباح");
        final Button eBtn = tabBtn("🌙 المساء");
        LinearLayout.LayoutParams mp = new LinearLayout.LayoutParams(0, dp(50), 1f);
        mp.setMarginEnd(dp(6));
        LinearLayout.LayoutParams ep = new LinearLayout.LayoutParams(0, dp(50), 1f);
        mBtn.setOnClickListener(v -> { morning = true; progress.clear(); paintTabs(mBtn, eBtn); renderList(); });
        eBtn.setOnClickListener(v -> { morning = false; progress.clear(); paintTabs(mBtn, eBtn); renderList(); });
        tabs.addView(mBtn, mp);
        tabs.addView(eBtn, ep);
        LinearLayout.LayoutParams tabsLp = new LinearLayout.LayoutParams(-1, -2);
        tabsLp.bottomMargin = dp(16);
        root.addView(tabs, tabsLp);
        paintTabs(mBtn, eBtn);

        listBox = new LinearLayout(this);
        listBox.setOrientation(LinearLayout.VERTICAL);
        root.addView(listBox);

        Button reset = new Button(this);
        reset.setText("تصفير العدّادات");
        reset.setAllCaps(false);
        reset.setTextColor(0xFFF2685C);
        GradientDrawable rg = new GradientDrawable();
        rg.setColor(0x33F2685C);
        rg.setCornerRadius(dp(14));
        reset.setBackground(rg);
        reset.setOnClickListener(v -> { progress.clear(); renderList(); });
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, dp(54));
        rp.topMargin = dp(14);
        root.addView(reset, rp);

        sv.addView(root);
        setContentView(sv);
        renderList();
    }

    Button tabBtn(String s) {
        Button b = new Button(this);
        b.setText(s);
        b.setAllCaps(false);
        b.setTextSize(15);
        GradientDrawable g = new GradientDrawable();
        g.setCornerRadius(dp(12));
        b.setBackground(g);
        return b;
    }

    void paintTabs(Button mBtn, Button eBtn) {
        GradientDrawable gm = new GradientDrawable(); gm.setCornerRadius(dp(12));
        gm.setColor(morning ? SUN : BTN);
        mBtn.setBackground(gm);
        mBtn.setTextColor(morning ? 0xFF2a1a06 : TXT);

        GradientDrawable ge = new GradientDrawable(); ge.setCornerRadius(dp(12));
        ge.setColor(!morning ? MINT : BTN);
        eBtn.setBackground(ge);
        eBtn.setTextColor(!morning ? 0xFF06251F : TXT);
    }

    void renderList() {
        listBox.removeAllViews();
        String[][] data = morning ? MORNING : EVENING;
        for (int i = 0; i < data.length; i++) {
            listBox.addView(item(i, data[i][0], Integer.parseInt(data[i][1])));
        }
    }

    View item(final int idx, String text, final int target) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(16), dp(14), dp(16), dp(14));
        GradientDrawable g = new GradientDrawable();
        g.setCornerRadius(dp(16));
        int done = progress.containsKey(idx) && progress.get(idx) >= target ? 1 : 0;
        g.setColor(done == 1 ? 0x225FE3C4 : CARD);
        g.setStroke(done == 1 ? dp(1) : 0, MINT);
        c.setBackground(g);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.bottomMargin = dp(10);
        c.setLayoutParams(lp);

        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(16);
        t.setTextColor(TXT);
        t.setLineSpacing(dp(4), 1f);
        c.addView(t);

        LinearLayout row = new LinearLayout(this);
        row.setPadding(0, dp(10), 0, 0);
        row.setGravity(Gravity.CENTER_VERTICAL);
        TextView badge = new TextView(this);
        int cur = progress.containsKey(idx) ? progress.get(idx) : 0;
        badge.setText((done == 1 ? "✓ " : "") + cur + " / " + target);
        badge.setTextColor(done == 1 ? MINT : SUN);
        badge.setTextSize(13);
        badge.setTypeface(null, Typeface.BOLD);
        row.addView(badge, new LinearLayout.LayoutParams(0, -2, 1f));
        c.addView(row);

        c.setOnClickListener(v -> {
            int val = progress.containsKey(idx) ? progress.get(idx) : 0;
            if (val < target) {
                val++;
                progress.put(idx, val);
                renderList();
            }
        });
        return c;
    }
}
