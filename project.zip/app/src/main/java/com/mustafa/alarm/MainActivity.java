package com.mustafa.alarm;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.NotificationManager;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import java.time.LocalDate;
import java.util.List;
import java.util.Locale;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import androidx.core.app.ActivityCompat;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.Date;
import android.os.Handler;
import android.os.Looper;

public class MainActivity extends Activity {
    static final int BG = 0xFF0E1428, CARD = 0xFF182047, TXT = 0xFFEEF1FB,
            MUTED = 0xFF8992BE, SUN = 0xFFF5A25C, MINT = 0xFF5FE3C4, RED = 0xFFF2685C,
            BTN = 0xFF212A56, GREEN = 0xFF34C759;
    static final String[] DOW = {"أحد", "اثنين", "ثلاثاء", "أربعاء", "خميس", "جمعة", "سبت"};

    LinearLayout list;
    List<AlarmStore.A> alarms;
    AlarmStore.A toneTarget;
    TextView clockTv, dateTv;
    Handler clockHandler = new Handler(Looper.getMainLooper());

    int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }

    TextView tv(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(null, Typeface.BOLD);
        return t;
    }

    Button btn(String s, int bg, int fg) {
        Button b = new Button(this);
        b.setText(s);
        b.setTextColor(fg);
        b.setAllCaps(false);
        GradientDrawable g = new GradientDrawable();
        g.setColor(bg);
        g.setCornerRadius(dp(12));
        b.setBackground(g);
        return b;
    }

    void tintGreen(Switch sw) {
        ColorStateList thumb = new ColorStateList(
                new int[][]{{android.R.attr.state_checked}, {}},
                new int[]{GREEN, 0xFFB9BEDA});
        ColorStateList track = new ColorStateList(
                new int[][]{{android.R.attr.state_checked}, {}},
                new int[]{0x8034C759, 0x55B9BEDA});
        sw.setThumbTintList(thumb);
        sw.setTrackTintList(track);
    }

    static String fmt(int m) {
        int h = m / 60;
        int h12 = (h % 12 == 0) ? 12 : h % 12;
        return String.format(Locale.ENGLISH, "%d:%02d %s", h12, m % 60, h >= 12 ? "م" : "ص");
    }

    static String daysText(int mask) {
        if (mask == 0 || mask == AlarmStore.ALL_DAYS) return "كل يوم";
        int n = 0;
        for (int i = 0; i < 7; i++) if ((mask & (1 << i)) != 0) n++;
        if (n == 0) return "كل يوم";
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 7; i++) {
            if ((mask & (1 << i)) != 0) {
                if (sb.length() > 0) sb.append("، ");
                sb.append(DOW[i]);
            }
        }
        return sb.toString();
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
        }
        if (Build.VERSION.SDK_INT >= 34) {
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (!nm.canUseFullScreenIntent()
                    && !getSharedPreferences("alarms", 0).getBoolean("asked", false)) {
                getSharedPreferences("alarms", 0).edit().putBoolean("asked", true).apply();
                try {
                    startActivity(new Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT,
                            Uri.parse("package:" + getPackageName())));
                } catch (Exception e) { }
            }
        }

        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(BG);
        sv.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        sv.setFitsSystemWindows(true);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(24), dp(16), dp(24));

        TextView moon = tv("🌙", 30, SUN, false);
        moon.setGravity(Gravity.CENTER);
        root.addView(moon);

        TextView title = tv("منبّهاتي", 24, TXT, true);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, dp(4), 0, dp(10));
        root.addView(title);

        // الساعة الإلكترونية
        clockTv = tv("--:--:--", 46, SUN, true);
        clockTv.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams ctp = new LinearLayout.LayoutParams(-1, -2);
        ctp.bottomMargin = dp(2);
        root.addView(clockTv, ctp);

        dateTv = tv("", 13, MUTED, false);
        dateTv.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams dtp = new LinearLayout.LayoutParams(-1, -2);
        dtp.bottomMargin = dp(16);
        root.addView(dateTv, dtp);

        Button addTop = btn("+ إضافة منبّه جديد", SUN, 0xFF06251F);
        addTop.setOnClickListener(v -> {
            AlarmStore.A a = new AlarmStore.A();
            int max = 0;
            for (AlarmStore.A x : alarms) if (x.id > max) max = x.id;
            a.id = max + 1;
            a.start = LocalDate.now().toEpochDay();
            alarms.add(a);
            commit(a);
        });
        LinearLayout.LayoutParams atp = new LinearLayout.LayoutParams(-1, dp(52));
        atp.bottomMargin = dp(16);
        root.addView(addTop, atp);

        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams listLp = new LinearLayout.LayoutParams(-1, -2);
        listLp.bottomMargin = dp(90); // حتى لا يحجبها الشريط السفلي
        root.addView(list, listLp);

        android.content.SharedPreferences crashSp = getSharedPreferences("crash", MODE_PRIVATE);
        if (crashSp.contains("last")) {
            Button crashBtn = btn("🐞 عرض آخر عطل (للمساعدة في الإصلاح)", 0x33F2685C, 0xFFF2685C);
            LinearLayout.LayoutParams cbp = new LinearLayout.LayoutParams(-1, -2);
            cbp.topMargin = dp(14);
            crashBtn.setOnClickListener(v -> {
                String trace = crashSp.getString("last", "لا يوجد");
                long t = crashSp.getLong("time", 0);
                String when = t > 0 ? new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new java.util.Date(t)) : "";
                android.widget.TextView tv = new android.widget.TextView(this);
                tv.setText(when + "\n\n" + trace);
                tv.setTextIsSelectable(true);
                tv.setTextSize(12);
                tv.setPadding(dp(16), dp(12), dp(16), dp(12));
                android.widget.ScrollView sv2 = new android.widget.ScrollView(this);
                sv2.addView(tv);
                new android.app.AlertDialog.Builder(this)
                        .setTitle("آخر عطل مسجَّل")
                        .setView(sv2)
                        .setPositiveButton("إغلاق", null)
                        .setNegativeButton("مسح", (d, w) -> { crashSp.edit().clear().apply(); recreate(); })
                        .show();
            });
            root.addView(crashBtn, cbp);
        }

        sv.addView(root);

        android.widget.FrameLayout screen = new android.widget.FrameLayout(this);
        screen.setBackgroundColor(BG);
        screen.addView(sv, new android.widget.FrameLayout.LayoutParams(-1, -1));
        screen.addView(buildBottomNav(), new android.widget.FrameLayout.LayoutParams(
                -1, -2, Gravity.BOTTOM));

        setContentView(screen);
        refresh();
        startClock();
    }

    View buildBottomNav() {
        LinearLayout bar = new LinearLayout(this);
        bar.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(8), dp(10), dp(8), dp(10));
        GradientDrawable barBg = new GradientDrawable();
        barBg.setColor(CARD);
        barBg.setCornerRadius(dp(26));
        bar.setBackground(barBg);
        LinearLayout.LayoutParams barLp = new LinearLayout.LayoutParams(-1, -2);
        barLp.setMargins(dp(14), 0, dp(14), dp(14));
        bar.setLayoutParams(barLp);

        bar.addView(navIcon("📍", false, v -> startActivity(new Intent(this, PrayerTimesActivity.class))));
        bar.addView(navIcon("📿", false, v -> startActivity(new Intent(this, TasbihActivity.class))));
        bar.addView(navIcon("⏰", false, v -> {
            android.widget.ScrollView parent = (android.widget.ScrollView) list.getParent().getParent();
            parent.smoothScrollTo(0, 0);
        }));
        bar.addView(navIcon("🌙", false, v -> startActivity(new Intent(this, AdhkarActivity.class))));
        View quranIcon = navIcon("📖", false, v -> startActivity(new Intent(this, MushafPagesActivity.class)));
        quranIcon.setOnLongClickListener(v -> {
            String[] options = {"📑 فهرس السور", "🔖 الرجوع إلى آخر علامة", "📝 تفسير آية (بحث)"};
            new AlertDialog.Builder(this)
                    .setTitle("المصحف الشريف")
                    .setItems(options, (d, which) -> {
                        if (which == 0) startActivity(new Intent(this, SurahIndexActivity.class));
                        else if (which == 1) {
                            android.content.SharedPreferences msp = getSharedPreferences("mushafpages", 0);
                            Intent it = new Intent(this, MushafPagesActivity.class);
                            it.putExtra("page", msp.getInt("lastPage", 0));
                            startActivity(it);
                        } else startActivity(new Intent(this, QuranActivity.class));
                    })
                    .show();
            return true;
        });
        bar.addView(quranIcon);
        return bar;
    }

    View navIcon(String emoji, boolean raised, View.OnClickListener onClick) {
        TextView t = new TextView(this);
        t.setText(emoji);
        t.setTextSize(22);
        t.setGravity(Gravity.CENTER);
        int size = dp(44);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, size, 1f);
        t.setLayoutParams(lp);
        t.setOnClickListener(onClick);
        return t;
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (alarms != null) refresh();
        startClock();
    }

    @Override
    protected void onPause() {
        super.onPause();
        clockHandler.removeCallbacksAndMessages(null);
    }

    void startClock() {
        clockHandler.removeCallbacksAndMessages(null);
        Runnable tick = new Runnable() {
            @Override public void run() {
                java.util.Date now = new java.util.Date();
                clockTv.setText(new SimpleDateFormat("h:mm:ss a", new Locale("ar")).format(now));
                dateTv.setText(new SimpleDateFormat("EEEE d MMMM yyyy", new Locale("ar")).format(now));
                clockHandler.postDelayed(this, 1000);
            }
        };
        clockHandler.post(tick);
    }

    void refresh() {
        alarms = AlarmStore.load(this);
        list.removeAllViews();
        for (AlarmStore.A a : alarms) list.addView(card(a));
    }

    void commit(AlarmStore.A a) {
        AlarmStore.save(this, alarms);
        if (!AlarmStore.schedule(this, a)) {
            Toast.makeText(this, "فعّل إذن المنبّهات والتذكيرات للتطبيق", Toast.LENGTH_LONG).show();
            if (Build.VERSION.SDK_INT >= 31) {
                try {
                    startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                            Uri.parse("package:" + getPackageName())));
                } catch (Exception e) { }
            }
        }
        refresh();
    }

    String summary(AlarmStore.A a) {
        String s;
        if (a.mode == 0) s = "ثابت";
        else s = (a.mode == 1 ? "يتقدّم " : "يتأخر ") + a.step + " د بعد كل تنبيه";
        if (a.mode != 0 && a.tOn) s += " • حتى " + fmt(a.tMin);
        return s + " • " + daysText(a.daysMask);
    }

    String toneName(AlarmStore.A a) {
        if (a.tone == null || a.tone.isEmpty()) return "النغمة الافتراضية";
        try {
            return RingtoneManager.getRingtone(this, Uri.parse(a.tone)).getTitle(this);
        } catch (Exception e) {
            return "نغمة مخصصة";
        }
    }

    View card(final AlarmStore.A a) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(16), dp(14), dp(16), dp(14));
        GradientDrawable g = new GradientDrawable();
        g.setColor(CARD);
        g.setCornerRadius(dp(18));
        c.setBackground(g);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.bottomMargin = dp(12);
        c.setLayoutParams(lp);

        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        TextView time = tv(fmt(a.min), 30, a.on ? TXT : MUTED, true);
        time.setOnClickListener(v -> new TimePickerDialog(this, (p, hh, mm) -> {
            a.min = hh * 60 + mm;
            a.start = LocalDate.now().toEpochDay();
            commit(a);
        }, a.min / 60, a.min % 60, false).show());
        row.addView(time, new LinearLayout.LayoutParams(0, -2, 1f));
        Switch sw = new Switch(this);
        tintGreen(sw);
        sw.setChecked(a.on);
        sw.setOnCheckedChangeListener((v, on) -> { a.on = on; commit(a); });
        row.addView(sw);
        c.addView(row);

        c.addView(tv(summary(a), 13, MINT, false));
        c.addView(tv("🔔 " + toneName(a), 12, MUTED, false));

        LinearLayout br = new LinearLayout(this);
        br.setPadding(0, dp(10), 0, 0);
        Button s = btn("الإعدادات", BTN, TXT);
        s.setOnClickListener(v -> settings(a));
        Button d = btn("حذف", 0x33F2685C, RED);
        d.setOnClickListener(v -> {
            AlarmStore.cancel(this, a.id);
            alarms.remove(a);
            AlarmStore.save(this, alarms);
            refresh();
        });
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(0, -2, 1f);
        bp.setMarginEnd(dp(8));
        br.addView(s, bp);
        br.addView(d, new LinearLayout.LayoutParams(0, -2, 1f));
        c.addView(br);
        return c;
    }

    void settings(final AlarmStore.A a) {
        LinearLayout v = new LinearLayout(this);
        v.setOrientation(LinearLayout.VERTICAL);
        v.setPadding(dp(20), dp(10), dp(20), 0);
        v.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        // أيام التكرار
        v.addView(tv("أيام التكرار", 15, 0xFF000000, true));
        final boolean[] daySel = new boolean[7];
        int mask0 = a.daysMask == 0 ? AlarmStore.ALL_DAYS : a.daysMask;
        for (int i = 0; i < 7; i++) daySel[i] = (mask0 & (1 << i)) != 0;

        LinearLayout dayRow = new LinearLayout(this);
        dayRow.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        final Button[] dayBtns = new Button[7];
        for (int i = 0; i < 7; i++) {
            final int idx = i;
            Button db = btn(DOW[i].substring(0, 1), daySel[i] ? MINT : BTN, daySel[i] ? 0xFF06251F : TXT);
            db.setTextSize(13);
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(44), 1f);
            p.setMarginEnd(dp(4));
            db.setOnClickListener(x -> {
                daySel[idx] = !daySel[idx];
                dayBtns[idx].setBackgroundColor(daySel[idx] ? MINT : BTN);
                dayBtns[idx].setTextColor(daySel[idx] ? 0xFF06251F : TXT);
            });
            dayBtns[i] = db;
            dayRow.addView(db, p);
        }
        v.addView(dayRow);

        Button everyDay = btn("كل يوم", BTN, SUN);
        everyDay.setOnClickListener(x -> {
            for (int i = 0; i < 7; i++) {
                daySel[i] = true;
                dayBtns[i].setBackgroundColor(MINT);
                dayBtns[i].setTextColor(0xFF06251F);
            }
        });
        LinearLayout.LayoutParams edp = new LinearLayout.LayoutParams(-1, -2);
        edp.topMargin = dp(8);
        edp.bottomMargin = dp(14);
        v.addView(everyDay, edp);

        v.addView(tv("الضبط اليومي التلقائي", 15, 0xFF000000, true));
        final RadioGroup rg = new RadioGroup(this);
        String[] names = {"أبكر بعد كل تنبيه", "ثابت", "أتأخر بعد كل تنبيه"};
        for (int i = 0; i < 3; i++) {
            RadioButton rb = new RadioButton(this);
            rb.setText(names[i]);
            rb.setId(100 + i);
            rg.addView(rb);
        }
        rg.check(100 + (a.mode == 1 ? 0 : (a.mode == 0 ? 1 : 2)));
        v.addView(rg);

        final EditText st = new EditText(this);
        st.setInputType(InputType.TYPE_CLASS_NUMBER);
        st.setText(String.valueOf(a.step));
        st.setHint("الدقائق بعد كل تنبيه");
        v.addView(st);

        final CheckBox cb = new CheckBox(this);
        cb.setText("التوقف عند وقت محدد");
        cb.setChecked(a.tOn);
        v.addView(cb);

        final Button tb = btn(fmt(a.tMin), BTN, TXT);
        tb.setOnClickListener(x -> new TimePickerDialog(this, (p, hh, mm) -> {
            a.tMin = hh * 60 + mm;
            tb.setText(fmt(a.tMin));
        }, a.tMin / 60, a.tMin % 60, false).show());
        v.addView(tb);

        Button tn = btn("اختيار النغمة من الجهاز", BTN, TXT);
        tn.setOnClickListener(x -> {
            toneTarget = a;
            Intent it = new Intent(RingtoneManager.ACTION_RINGTONE_PICKER);
            it.putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_ALARM);
            it.putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE, "اختر النغمة");
            if (a.tone != null && !a.tone.isEmpty())
                it.putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, Uri.parse(a.tone));
            startActivityForResult(it, 1);
        });
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(-1, -2);
        tp.topMargin = dp(10);
        v.addView(tn, tp);

        new AlertDialog.Builder(this)
                .setTitle("إعدادات المنبّه")
                .setView(v)
                .setPositiveButton("حفظ", (dlg, which) -> {
                    int idx = rg.getCheckedRadioButtonId() - 100;
                    a.mode = idx == 0 ? 1 : (idx == 1 ? 0 : 2);
                    try {
                        a.step = Math.max(1, Math.min(120, Integer.parseInt(st.getText().toString().trim())));
                    } catch (Exception e) { }
                    a.tOn = cb.isChecked();
                    int mask = 0;
                    for (int i = 0; i < 7; i++) if (daySel[i]) mask |= (1 << i);
                    a.daysMask = mask == 0 ? AlarmStore.ALL_DAYS : mask;
                    a.start = LocalDate.now().toEpochDay();
                    commit(a);
                })
                .setNegativeButton("إلغاء", null)
                .show();
    }

    @Override
    protected void onActivityResult(int rq, int rs, Intent data) {
        super.onActivityResult(rq, rs, data);
        if (rq == 1 && rs == RESULT_OK && data != null && toneTarget != null) {
            Uri u = data.getParcelableExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI);
            toneTarget.tone = (u == null) ? "" : u.toString();
            // نحفظ فورًا حتى لو أُغلق مربع الإعدادات قبل الضغط على حفظ
            AlarmStore.save(this, alarms);
            AlarmStore.schedule(this, toneTarget);
            refresh();
            Toast.makeText(this, "تم حفظ النغمة", Toast.LENGTH_SHORT).show();
        }
    }
}
