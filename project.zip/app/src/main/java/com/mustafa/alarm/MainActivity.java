package com.mustafa.alarm;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.NotificationManager;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import java.time.LocalDate;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    static final int BG = 0xFF0E1428, CARD = 0xFF182047, TXT = 0xFFEEF1FB,
            MUTED = 0xFF8992BE, SUN = 0xFFF5A25C, MINT = 0xFF5FE3C4, RED = 0xFFF2685C, BTN = 0xFF212A56;
    LinearLayout list;
    List<AlarmStore.A> alarms;
    AlarmStore.A toneTarget;

    int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }

    TextView tv(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(null, Typeface.BOLD);
        return t;
    }

    Button btn(String s, int bg, int fg) {
        Button b = new Button(this);
        b.setText(s);
        b.setTextColor(fg);
        b.setAllCaps(false);
        GradientDrawable g = new GradientDrawable();
        g.setColor(bg);
        g.setCornerRadius(dp(12));
        b.setBackground(g);
        return b;
    }

    static String fmt(int m) {
        int h = m / 60;
        int h12 = (h % 12 == 0) ? 12 : h % 12;
        return String.format(Locale.ENGLISH, "%d:%02d %s", h12, m % 60, h >= 12 ? "م" : "ص");
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
        }
        if (Build.VERSION.SDK_INT >= 34) {
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (!nm.canUseFullScreenIntent()
                    && !getSharedPreferences("alarms", 0).getBoolean("asked", false)) {
                getSharedPreferences("alarms", 0).edit().putBoolean("asked", true).apply();
                try {
                    startActivity(new Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT,
                            Uri.parse("package:" + getPackageName())));
                } catch (Exception e) { }
            }
        }

        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(BG);
        sv.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        sv.setFitsSystemWindows(true);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(24), dp(16), dp(24));

        TextView title = tv("منبّهاتي", 24, TXT, true);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, 0, 0, dp(16));
        root.addView(title);

        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        root.addView(list);

        Button add = btn("+ إضافة منبّه جديد", CARD, SUN);
        add.setOnClickListener(v -> {
            AlarmStore.A a = new AlarmStore.A();
            int max = 0;
            for (AlarmStore.A x : alarms) if (x.id > max) max = x.id;
            a.id = max + 1;
            a.start = LocalDate.now().toEpochDay();
            alarms.add(a);
            commit(a);
        });
        root.addView(add);

        sv.addView(root);
        setContentView(sv);
        refresh();
    }

    void refresh() {
        alarms = AlarmStore.load(this);
        list.removeAllViews();
        for (AlarmStore.A a : alarms) list.addView(card(a));
    }

    void commit(AlarmStore.A a) {
        AlarmStore.save(this, alarms);
        AlarmStore.schedule(this, a);
        refresh();
    }

    String summary(AlarmStore.A a) {
        String s;
        if (a.mode == 0) s = "ثابت كل يوم";
        else s = (a.mode == 1 ? "يتقدّم " : "يتأخر ") + a.step + " د/يوم";
        if (a.mode != 0 && a.tOn) s += " • حتى " + fmt(a.tMin);
        return s;
    }

    String toneName(AlarmStore.A a) {
        if (a.tone == null || a.tone.isEmpty()) return "النغمة الافتراضية";
        try {
            return RingtoneManager.getRingtone(this, Uri.parse(a.tone)).getTitle(this);
        } catch (Exception e) {
            return "نغمة مخصصة";
        }
    }

    View card(final AlarmStore.A a) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(16), dp(14), dp(16), dp(14));
        GradientDrawable g = new GradientDrawable();
        g.setColor(CARD);
        g.setCornerRadius(dp(18));
        c.setBackground(g);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.bottomMargin = dp(12);
        c.setLayoutParams(lp);

        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        TextView time = tv(fmt(a.min), 30, a.on ? TXT : MUTED, true);
        time.setOnClickListener(v -> new TimePickerDialog(this, (p, hh, mm) -> {
            a.min = hh * 60 + mm;
            a.start = LocalDate.now().toEpochDay();
            commit(a);
        }, a.min / 60, a.min % 60, false).show());
        row.addView(time, new LinearLayout.LayoutParams(0, -2, 1f));
        Switch sw = new Switch(this);
        sw.setChecked(a.on);
        sw.setOnCheckedChangeListener((v, on) -> { a.on = on; commit(a); });
        row.addView(sw);
        c.addView(row);

        c.addView(tv(summary(a), 13, MINT, false));
        c.addView(tv("🔔 " + toneName(a), 12, MUTED, false));

        LinearLayout br = new LinearLayout(this);
        br.setPadding(0, dp(10), 0, 0);
        Button s = btn("الإعدادات", BTN, TXT);
        s.setOnClickListener(v -> settings(a));
        Button d = btn("حذف", 0x33F2685C, RED);
        d.setOnClickListener(v -> {
            AlarmStore.cancel(this, a.id);
            alarms.remove(a);
            AlarmStore.save(this, alarms);
            refresh();
        });
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(0, -2, 1f);
        bp.setMarginEnd(dp(8));
        br.addView(s, bp);
        br.addView(d, new LinearLayout.LayoutParams(0, -2, 1f));
        c.addView(br);
        return c;
    }

    void settings(final AlarmStore.A a) {
        LinearLayout v = new LinearLayout(this);
        v.setOrientation(LinearLayout.VERTICAL);
        v.setPadding(dp(20), dp(10), dp(20), 0);
        v.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        v.addView(tv("الضبط اليومي التلقائي", 15, 0xFF000000, true));
        final RadioGroup rg = new RadioGroup(this);
        String[] names = {"أبكر كل يوم", "ثابت", "أتأخر كل يوم"};
        for (int i = 0; i < 3; i++) {
            RadioButton rb = new RadioButton(this);
            rb.setText(names[i]);
            rb.setId(100 + i);
            rg.addView(rb);
        }
        rg.check(100 + (a.mode == 1 ? 0 : (a.mode == 0 ? 1 : 2)));
        v.addView(rg);

        final EditText st = new EditText(this);
        st.setInputType(InputType.TYPE_CLASS_NUMBER);
        st.setText(String.valueOf(a.step));
        st.setHint("الدقائق كل يوم");
        v.addView(st);

        final CheckBox cb = new CheckBox(this);
        cb.setText("التوقف عند وقت محدد");
        cb.setChecked(a.tOn);
        v.addView(cb);

        final Button tb = btn(fmt(a.tMin), BTN, TXT);
        tb.setOnClickListener(x -> new TimePickerDialog(this, (p, hh, mm) -> {
            a.tMin = hh * 60 + mm;
            tb.setText(fmt(a.tMin));
        }, a.tMin / 60, a.tMin % 60, false).show());
        v.addView(tb);

        Button tn = btn("اختيار النغمة من الجهاز", BTN, TXT);
        tn.setOnClickListener(x -> {
            toneTarget = a;
            Intent it = new Intent(RingtoneManager.ACTION_RINGTONE_PICKER);
            it.putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_ALARM);
            it.putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE, "اختر النغمة");
            if (a.tone != null && !a.tone.isEmpty())
                it.putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, Uri.parse(a.tone));
            startActivityForResult(it, 1);
        });
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(-1, -2);
        tp.topMargin = dp(10);
        v.addView(tn, tp);

        new AlertDialog.Builder(this)
                .setTitle("إعدادات المنبّه")
                .setView(v)
                .setPositiveButton("حفظ", (dlg, which) -> {
                    int idx = rg.getCheckedRadioButtonId() - 100;
                    a.mode = idx == 0 ? 1 : (idx == 1 ? 0 : 2);
                    try {
                        a.step = Math.max(1, Math.min(120, Integer.parseInt(st.getText().toString().trim())));
                    } catch (Exception e) { }
                    a.tOn = cb.isChecked();
                    a.start = LocalDate.now().toEpochDay();
                    commit(a);
                })
                .setNegativeButton("إلغاء", null)
                .show();
    }

    @Override
    protected void onActivityResult(int rq, int rs, Intent data) {
        super.onActivityResult(rq, rs, data);
        if (rq == 1 && rs == RESULT_OK && data != null && toneTarget != null) {
            Uri u = data.getParcelableExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI);
            toneTarget.tone = (u == null) ? "" : u.toString();
            Toast.makeText(this, "تم اختيار النغمة، اضغط حفظ", Toast.LENGTH_SHORT).show();
        }
    }
}
