package com.mustafa.alarm;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;

/** قارئ بسيط: كل آية TextView مستقل في قائمة عمودية عادية (بدون أي تخطيط مخصّص)، أثبت الأنواع السابقة أنها مستقرة. */
public class SurahReadActivity extends Activity {
    static final int BG = 0xFF0E1428, CARD = 0xFF182047, TXT = 0xFFEEF1FB,
            MUTED = 0xFF8992BE, SUN = 0xFFF5A25C, MINT = 0xFF5FE3C4;

    int num;
    String name;
    List<String> ayahText = new ArrayList<>();
    String[] tafsirArr;
    LinearLayout list;
    TextView status;

    int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        num = getIntent().getIntExtra("num", 1);
        name = getIntent().getStringExtra("name");

        getSharedPreferences("quran", 0).edit().putInt("lastSurah", num).putString("lastName", name).apply();

        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(BG);
        sv.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        sv.setFitsSystemWindows(true);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(22), dp(16), dp(30));

        TextView title = new TextView(this);
        title.setText("سورة " + (name == null ? "" : name));
        title.setTextSize(22);
        title.setTypeface(null, Typeface.BOLD);
        title.setTextColor(SUN);
        title.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(-1, -2);
        tp.bottomMargin = dp(6);
        root.addView(title, tp);

        TextView hint = new TextView(this);
        hint.setText("اضغط مطوّلًا على أي آية لعرض تفسيرها");
        hint.setTextSize(12.5f);
        hint.setTextColor(MUTED);
        hint.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(-1, -2);
        hp.bottomMargin = dp(16);
        root.addView(hint, hp);

        status = new TextView(this);
        status.setText("جارٍ تحميل السورة...");
        status.setTextColor(MUTED);
        status.setGravity(Gravity.CENTER);
        status.setPadding(0, dp(20), 0, dp(20));
        root.addView(status);

        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        root.addView(list);

        sv.addView(root);
        setContentView(sv);

        loadAyat();
    }

    void loadAyat() {
        Net.get("https://api.alquran.cloud/v1/surah/" + num + "/quran-uthmani", (json, err) -> runOnUiThread(() -> {
            if (err != null || json == null) {
                status.setText("تعذّر تحميل السورة. اضغط للمحاولة مجددًا");
                status.setOnClickListener(v -> { status.setText("جارٍ تحميل السورة..."); loadAyat(); });
                return;
            }
            try {
                JSONObject o = new JSONObject(json);
                JSONArray ayahs = o.getJSONObject("data").getJSONArray("ayahs");
                ayahText.clear();
                for (int i = 0; i < ayahs.length(); i++) ayahText.add(ayahs.getJSONObject(i).getString("text"));
                status.setVisibility(View.GONE);
                list.removeAllViews();
                for (int i = 0; i < ayahText.size(); i++) list.addView(ayahCard(i + 1, ayahText.get(i)));
                loadTafsirInBackground();
            } catch (Exception e) {
                status.setText("تعذّرت قراءة بيانات السورة");
            }
        }));
    }

    void loadTafsirInBackground() {
        Net.get("https://cdn.jsdelivr.net/gh/spa5k/tafsir_api@main/tafsir/ar-tafsir-muyassar/" + num + ".json",
            (json, err) -> {
                if (err != null || json == null) return;
                try {
                    JSONObject o = new JSONObject(json);
                    JSONArray arr = o.getJSONArray("ayahs");
                    String[] t = new String[arr.length()];
                    for (int i = 0; i < arr.length(); i++) {
                        JSONObject a = arr.getJSONObject(i);
                        t[i] = a.has("text") ? a.getString("text") : "";
                    }
                    tafsirArr = t;
                } catch (Exception e) { }
            });
    }

    View ayahCard(int n, String text) {
        TextView t = new TextView(this);
        t.setText(text + "  ﴿" + n + "﴾");
        t.setTextSize(20);
        t.setTextColor(TXT);
        t.setLineSpacing(dp(5), 1f);
        t.setPadding(dp(16), dp(14), dp(16), dp(14));
        GradientDrawable g = new GradientDrawable();
        g.setColor(CARD);
        g.setCornerRadius(dp(16));
        t.setBackground(g);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.bottomMargin = dp(10);
        t.setLayoutParams(lp);
        t.setOnLongClickListener(v -> {
            if (tafsirArr == null) {
                Toast.makeText(this, "التفسير قيد التحميل، أعد المحاولة بعد قليل", Toast.LENGTH_SHORT).show();
            } else {
                String tf = (n - 1 < tafsirArr.length) ? tafsirArr[n - 1] : "لا يتوفر تفسير";
                TextView tv = new TextView(this);
                tv.setText(tf);
                tv.setTextSize(15);
                tv.setLineSpacing(dp(4), 1f);
                tv.setPadding(dp(18), dp(14), dp(18), dp(6));
                tv.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
                ScrollView s = new ScrollView(this);
                s.addView(tv);
                new AlertDialog.Builder(this)
                        .setTitle("تفسير الآية " + n)
                        .setView(s)
                        .setPositiveButton("إغلاق", null)
                        .show();
            }
            return true;
        });
        return t;
    }
}
