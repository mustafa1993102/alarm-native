package com.mustafa.alarm;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.GestureDetector;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;

/**
 * عرض السورة كنص متدفّق متواصل (سطور) كالمصحف العادي، بدل مربّع منفصل لكل آية.
 * الكشف عن الآية المضغوط عليها يتم عبر إحداثيات اللمس داخل TextView واحد فقط،
 * دون أي تخطيط (ViewGroup) مخصّص — نفس الطريقة الآمنة التي استُخدمت في الأذكار والمسبحة.
 */
public class SurahReadActivity extends Activity {
    static final int BG = 0xFF0E1428, CARD = 0xFF182047, TXT = 0xFFEEF1FB,
            MUTED = 0xFF8992BE, SUN = 0xFFF5A25C, MINT = 0xFF5FE3C4;

    int num;
    String name;
    String[] tafsirArr;
    TextView flowText;
    final List<int[]> ranges = new ArrayList<>(); // {start, endExclusive, ayahNumber}

    int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        num = getIntent().getIntExtra("num", 1);
        name = getIntent().getStringExtra("name");
        getSharedPreferences("quran", 0).edit().putInt("lastSurah", num).putString("lastName", name).apply();

        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(BG);
        sv.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        sv.setFitsSystemWindows(true);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(22), dp(18), dp(36));

        TextView title = new TextView(this);
        title.setText("سورة " + (name == null ? "" : name));
        title.setTextSize(22);
        title.setTypeface(null, Typeface.BOLD);
        title.setTextColor(SUN);
        title.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(-1, -2);
        tp.bottomMargin = dp(4);
        root.addView(title, tp);

        if (num != 9) {
            TextView bsm = new TextView(this);
            bsm.setText("بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ");
            bsm.setTextSize(19);
            bsm.setTypeface(null, Typeface.BOLD);
            bsm.setTextColor(TXT);
            bsm.setGravity(Gravity.CENTER);
            LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, -2);
            bp.topMargin = dp(10);
            bp.bottomMargin = dp(4);
            root.addView(bsm, bp);
        }

        TextView hint = new TextView(this);
        hint.setText("اضغط مطوّلًا في أي مكان من الآية لعرض تفسيرها");
        hint.setTextSize(12);
        hint.setTextColor(MUTED);
        hint.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(-1, -2);
        hp.topMargin = dp(8);
        hp.bottomMargin = dp(18);
        root.addView(hint, hp);

        TextView status = new TextView(this);
        status.setText("جارٍ تحميل السورة...");
        status.setTextColor(MUTED);
        status.setGravity(Gravity.CENTER);
        status.setPadding(0, dp(20), 0, dp(20));
        root.addView(status);

        flowText = new TextView(this);
        flowText.setTextSize(22);
        flowText.setTextColor(TXT);
        flowText.setLineSpacing(dp(10), 1.25f);
        flowText.setGravity(Gravity.RIGHT);
        flowText.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        flowText.setTextDirection(View.TEXT_DIRECTION_RTL);
        flowText.setVisibility(View.GONE);
        root.addView(flowText);

        sv.addView(root);
        setContentView(sv);

        final GestureDetector gd = new GestureDetector(this, new GestureDetector.SimpleOnGestureListener() {
            @Override public void onLongPress(MotionEvent e) { handleLongPress(e); }
        });
        flowText.setOnTouchListener((v, e) -> { gd.onTouchEvent(e); return false; });

        loadAyat(status);
    }

    void loadAyat(TextView status) {
        Net.get("https://api.alquran.cloud/v1/surah/" + num + "/quran-uthmani", (json, err) -> runOnUiThread(() -> {
            if (err != null || json == null) {
                status.setText("تعذّر تحميل السورة. اضغط للمحاولة مجددًا");
                status.setOnClickListener(v -> { status.setText("جارٍ تحميل السورة..."); loadAyat(status); });
                return;
            }
            try {
                JSONObject o = new JSONObject(json);
                JSONArray ayahs = o.getJSONObject("data").getJSONArray("ayahs");
                StringBuilder sb = new StringBuilder();
                ranges.clear();
                for (int i = 0; i < ayahs.length(); i++) {
                    String text = ayahs.getJSONObject(i).getString("text");
                    int start = sb.length();
                    sb.append(text).append("  ﴿").append(toArabicDigits(i + 1)).append("﴾  ");
                    ranges.add(new int[]{start, sb.length(), i + 1});
                }
                status.setVisibility(View.GONE);
                flowText.setText(sb.toString());
                flowText.setVisibility(View.VISIBLE);
                loadTafsirInBackground();
            } catch (Exception e) {
                status.setText("تعذّرت قراءة بيانات السورة");
            }
        }));
    }

    void loadTafsirInBackground() {
        Net.get("https://cdn.jsdelivr.net/gh/spa5k/tafsir_api@main/tafsir/ar-tafsir-muyassar/" + num + ".json",
            (json, err) -> {
                if (err != null || json == null) return;
                try {
                    JSONObject o = new JSONObject(json);
                    JSONArray arr = o.getJSONArray("ayahs");
                    String[] t = new String[arr.length()];
                    for (int i = 0; i < arr.length(); i++) {
                        JSONObject a = arr.getJSONObject(i);
                        t[i] = a.has("text") ? a.getString("text") : "";
                    }
                    tafsirArr = t;
                } catch (Exception e) { }
            });
    }

    void handleLongPress(MotionEvent e) {
        try {
            android.text.Layout layout = flowText.getLayout();
            if (layout == null) return;
            int x = (int) e.getX() - flowText.getTotalPaddingLeft() + flowText.getScrollX();
            int y = (int) e.getY() - flowText.getTotalPaddingTop() + flowText.getScrollY();
            int line = layout.getLineForVertical(y);
            int offset = layout.getOffsetForHorizontal(line, x);
            int ayah = -1;
            for (int[] r : ranges) if (offset >= r[0] && offset < r[1]) { ayah = r[2]; break; }
            if (ayah == -1 && !ranges.isEmpty()) ayah = ranges.get(ranges.size() - 1)[2];
            if (ayah == -1) return;
            showTafsir(ayah);
        } catch (Exception ex) { }
    }

    void showTafsir(int ayah) {
        if (tafsirArr == null) {
            Toast.makeText(this, "التفسير قيد التحميل، أعد المحاولة بعد قليل", Toast.LENGTH_SHORT).show();
            return;
        }
        String tf = (ayah - 1 >= 0 && ayah - 1 < tafsirArr.length) ? tafsirArr[ayah - 1] : "لا يتوفر تفسير لهذه الآية";
        TextView tv = new TextView(this);
        tv.setText(tf);
        tv.setTextSize(15);
        tv.setLineSpacing(dp(4), 1f);
        tv.setPadding(dp(18), dp(14), dp(18), dp(6));
        tv.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        ScrollView s = new ScrollView(this);
        s.addView(tv);
        new AlertDialog.Builder(this)
                .setTitle("تفسير الآية " + ayah)
                .setView(s)
                .setPositiveButton("إغلاق", null)
                .show();
    }

    static String toArabicDigits(int n) {
        String[] d = {"٠","١","٢","٣","٤","٥","٦","٧","٨","٩"};
        StringBuilder sb = new StringBuilder();
        for (char c : String.valueOf(n).toCharArray()) sb.append(d[c - '0']);
        return sb.toString();
    }
}
