package com.mustafa.alarm;

import android.app.Activity;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;

public class SurahReadActivity extends Activity {
    static final int BG = 0xFF0E1428, CARD = 0xFF182047, TXT = 0xFFEEF1FB,
            MUTED = 0xFF8992BE, SUN = 0xFFF5A25C, MINT = 0xFF5FE3C4, BTN = 0xFF212A56;

    int num;
    String name;
    boolean showTafsir = false;
    List<String> ayahText = new ArrayList<>();
    List<String> tafsirText = new ArrayList<>();
    LinearLayout list;
    TextView status;
    Button tafsirBtn;

    int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        num = getIntent().getIntExtra("num", 1);
        name = getIntent().getStringExtra("name");

        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(BG);
        sv.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        sv.setFitsSystemWindows(true);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(22), dp(16), dp(30));

        TextView title = new TextView(this);
        title.setText("سورة " + (name == null ? "" : name));
        title.setTextSize(22);
        title.setTypeface(null, Typeface.BOLD);
        title.setTextColor(SUN);
        title.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(-1, -2);
        tp.bottomMargin = dp(14);
        root.addView(title, tp);

        tafsirBtn = new Button(this);
        tafsirBtn.setAllCaps(false);
        refreshTafsirBtn();
        GradientDrawable tg = new GradientDrawable();
        tg.setCornerRadius(dp(14));
        tafsirBtn.setBackground(tg);
        tafsirBtn.setOnClickListener(v -> { showTafsir = !showTafsir; refreshTafsirBtn(); renderList(); });
        LinearLayout.LayoutParams tbp = new LinearLayout.LayoutParams(-1, dp(52));
        tbp.bottomMargin = dp(16);
        root.addView(tafsirBtn, tbp);

        status = new TextView(this);
        status.setText("جارٍ تحميل السورة...");
        status.setTextColor(MUTED);
        status.setGravity(Gravity.CENTER);
        status.setPadding(0, dp(20), 0, dp(20));
        root.addView(status);

        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        root.addView(list);

        sv.addView(root);
        setContentView(sv);

        loadAyat();
    }

    void refreshTafsirBtn() {
        tafsirBtn.setText(showTafsir ? "✓ إخفاء التفسير (الميسّر)" : "📖 إظهار التفسير (الميسّر)");
        GradientDrawable g = new GradientDrawable();
        g.setCornerRadius(dp(14));
        g.setColor(showTafsir ? 0x335FE3C4 : CARD);
        tafsirBtn.setBackground(g);
        tafsirBtn.setTextColor(showTafsir ? MINT : TXT);
    }

    void loadAyat() {
        Net.get("https://api.alquran.cloud/v1/surah/" + num + "/quran-uthmani", (json, err) -> runOnUiThread(() -> {
            if (err != null || json == null) {
                status.setText("تعذّر تحميل السورة. تحقق من الإنترنت واضغط للمحاولة");
                status.setOnClickListener(v -> { status.setText("جارٍ تحميل السورة..."); loadAyat(); });
                return;
            }
            try {
                JSONObject o = new JSONObject(json);
                JSONArray ayahs = o.getJSONObject("data").getJSONArray("ayahs");
                ayahText.clear();
                for (int i = 0; i < ayahs.length(); i++) {
                    ayahText.add(ayahs.getJSONObject(i).getString("text"));
                }
                status.setVisibility(View.GONE);
                renderList();
                loadTafsir();
            } catch (Exception e) {
                status.setText("تعذّرت قراءة بيانات السورة");
            }
        }));
    }

    void loadTafsir() {
        String url = "https://cdn.jsdelivr.net/gh/spa5k/tafsir_api@main/tafsir/ar-tafsir-muyassar/" + num + ".json";
        Net.get(url, (json, err) -> runOnUiThread(() -> {
            if (err != null || json == null) return;
            try {
                JSONObject o = new JSONObject(json);
                JSONArray ayahs = o.getJSONArray("ayahs");
                tafsirText.clear();
                for (int i = 0; i < ayahs.length(); i++) {
                    JSONObject a = ayahs.getJSONObject(i);
                    tafsirText.add(a.has("text") ? a.getString("text") : "");
                }
                if (showTafsir) renderList();
            } catch (Exception e) { }
        }));
    }

    void renderList() {
        list.removeAllViews();
        for (int i = 0; i < ayahText.size(); i++) {
            list.addView(ayahCard(i + 1, ayahText.get(i),
                    i < tafsirText.size() ? tafsirText.get(i) : null));
        }
    }

    View ayahCard(int n, String text, String tafsir) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(16), dp(14), dp(16), dp(14));
        GradientDrawable g = new GradientDrawable();
        g.setColor(CARD);
        g.setCornerRadius(dp(16));
        c.setBackground(g);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.bottomMargin = dp(10);
        c.setLayoutParams(lp);

        TextView t = new TextView(this);
        t.setText(text + "  ﴿" + n + "﴾");
        t.setTextSize(20);
        t.setTextColor(TXT);
        t.setLineSpacing(dp(6), 1f);
        c.addView(t);

        if (showTafsir) {
            View div = new View(this);
            LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(-1, dp(1));
            dlp.topMargin = dp(10);
            dlp.bottomMargin = dp(8);
            div.setBackgroundColor(0x22FFFFFF);
            c.addView(div, dlp);

            TextView tf = new TextView(this);
            tf.setText(tafsir != null && !tafsir.isEmpty() ? tafsir : "جارٍ تحميل التفسير...");
            tf.setTextSize(14.5f);
            tf.setTextColor(MINT);
            tf.setLineSpacing(dp(4), 1f);
            c.addView(tf);
        }
        return c;
    }
}
