package com.mustafa.alarm;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import java.util.ArrayList;
import java.util.List;

/** تخطيط يرتّب أبناءه كنص متدفّق من اليمين إلى اليسار، مع الانتقال لسطر جديد تلقائيًا. */
public class FlowLayout extends ViewGroup {
    int hGap, vGap;

    public FlowLayout(Context c) {
        super(c);
        hGap = (int) (6 * c.getResources().getDisplayMetrics().density);
        vGap = (int) (10 * c.getResources().getDisplayMetrics().density);
    }

    @Override
    protected void onMeasure(int widthSpec, int heightSpec) {
        int maxWidth = MeasureSpec.getSize(widthSpec);
        int count = getChildCount();
        int lineW = 0, lineH = 0, totalH = 0;
        for (int i = 0; i < count; i++) {
            View ch = getChildAt(i);
            measureChild(ch, widthSpec, heightSpec);
            int cw = ch.getMeasuredWidth(), chh = ch.getMeasuredHeight();
            if (lineW + cw > maxWidth && lineW > 0) {
                totalH += lineH + vGap;
                lineW = 0; lineH = 0;
            }
            lineW += cw + hGap;
            lineH = Math.max(lineH, chh);
        }
        totalH += lineH;
        setMeasuredDimension(maxWidth, totalH);
    }

    @Override
    protected void onLayout(boolean changed, int l, int t, int r, int b) {
        int width = r - l;
        int count = getChildCount();
        List<View> line = new ArrayList<>();
        int lineW = 0, y = 0, lineH = 0;
        for (int i = 0; i <= count; i++) {
            View ch = i < count ? getChildAt(i) : null;
            int cw = ch != null ? ch.getMeasuredWidth() : 0;
            boolean overflow = ch != null && lineW + cw > width && lineW > 0;
            if (overflow || ch == null) {
                int x = width;
                for (View v : line) {
                    int vw = v.getMeasuredWidth(), vh = v.getMeasuredHeight();
                    x -= vw;
                    int cy = y + (lineH - vh) / 2;
                    v.layout(x, cy, x + vw, cy + vh);
                    x -= hGap;
                }
                y += lineH + vGap;
                line.clear();
                lineW = 0; lineH = 0;
            }
            if (ch != null) {
                line.add(ch);
                lineW += cw + hGap;
                lineH = Math.max(lineH, ch.getMeasuredHeight());
            }
        }
    }
}
