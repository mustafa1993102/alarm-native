package com.mustafa.alarm;

import android.app.Application;
import android.content.SharedPreferences;
import java.io.PrintWriter;
import java.io.StringWriter;

/** يلتقط أي عطل غير متوقع ويحفظ تفاصيله محليًا لعرضها لاحقًا من داخل التطبيق. */
public class App extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        final Thread.UncaughtExceptionHandler prev = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler((thread, ex) -> {
            try {
                SharedPreferences sp = getSharedPreferences("crash", MODE_PRIVATE);
                StringWriter sw = new StringWriter();
                ex.printStackTrace(new PrintWriter(sw));
                sp.edit()
                  .putString("last", sw.toString())
                  .putLong("time", System.currentTimeMillis())
                  .apply();
            } catch (Exception ignore) { }
            if (prev != null) prev.uncaughtException(thread, ex);
            else {
                android.os.Process.killProcess(android.os.Process.myPid());
                System.exit(10);
            }
        });
    }
}
