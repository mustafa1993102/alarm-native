package com.mustafa.alarm;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.ZoneId;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class AlarmStore {
    // daysMask bits: bit0=الأحد..bit6=السبت (1=مفعّل ذلك اليوم)
    public static final int ALL_DAYS = 127;

    public static class A {
        public int id;
        public int min = 480;
        public boolean on = true;
        public int mode = 0;      // 0 ثابت، 1 أبكر، 2 أتأخر
        public int step = 5;
        public boolean tOn = false;
        public int tMin = 360;
        public String tone = "";
        public long start;
        public int daysMask = ALL_DAYS;
    }

    static SharedPreferences sp(Context c) { return c.getSharedPreferences("alarms", 0); }

    public static List<A> load(Context c) {
        List<A> l = new ArrayList<>();
        try {
            JSONArray ja = new JSONArray(sp(c).getString("list", "[]"));
            for (int i = 0; i < ja.length(); i++) {
                JSONObject o = ja.getJSONObject(i);
                A a = new A();
                a.id = o.getInt("id");
                a.min = o.getInt("min");
                a.on = o.getBoolean("on");
                a.mode = o.getInt("mode");
                a.step = o.getInt("step");
                a.tOn = o.getBoolean("tOn");
                a.tMin = o.getInt("tMin");
                a.tone = o.getString("tone");
                a.start = o.getLong("start");
                a.daysMask = o.has("daysMask") ? o.getInt("daysMask") : ALL_DAYS;
                l.add(a);
            }
        } catch (Exception e) { }
        return l;
    }

    public static void save(Context c, List<A> l) {
        JSONArray ja = new JSONArray();
        try {
            for (A a : l) {
                JSONObject o = new JSONObject();
                o.put("id", a.id);
                o.put("min", a.min);
                o.put("on", a.on);
                o.put("mode", a.mode);
                o.put("step", a.step);
                o.put("tOn", a.tOn);
                o.put("tMin", a.tMin);
                o.put("tone", a.tone == null ? "" : a.tone);
                o.put("start", a.start);
                o.put("daysMask", a.daysMask);
                ja.put(o);
            }
        } catch (Exception e) { }
        sp(c).edit().putString("list", ja.toString()).apply();
    }

    // Sunday=0 ... Saturday=6 مطابق لأزرار الواجهة
    static int dowBit(LocalDate d) {
        DayOfWeek w = d.getDayOfWeek();
        return w == DayOfWeek.SUNDAY ? 0 : w.getValue();
    }

    static boolean dayOn(A a, LocalDate d) {
        int mask = a.daysMask == 0 ? ALL_DAYS : a.daysMask;
        return (mask & (1 << dowBit(d))) != 0;
    }

    // عدد مرات رنين هذا المنبّه بين تاريخ البداية (start) وتاريخ الهدف (exclusive)
    static int occurrencesBetween(A a, long startEpoch, long targetEpoch) {
        int n = 0;
        LocalDate d = LocalDate.ofEpochDay(startEpoch);
        LocalDate end = LocalDate.ofEpochDay(targetEpoch);
        int guard = 0;
        while (d.isBefore(end) && guard < 4000) {
            if (dayOn(a, d)) n++;
            d = d.plusDays(1);
            guard++;
        }
        return n;
    }

    static int eff(A a, long dayEpoch) {
        if (a.mode == 0) return a.min;
        long start = a.start > 0 ? a.start : dayEpoch;
        int i = dayEpoch <= start ? 0 : occurrencesBetween(a, start, dayEpoch);
        long m = a.min + (a.mode == 1 ? -(long) a.step * i : (long) a.step * i);
        if (a.tOn) {
            if (a.mode == 1 && m <= a.tMin) m = a.tMin;
            if (a.mode == 2 && m >= a.tMin) m = a.tMin;
        }
        return (int) (((m % 1440) + 1440) % 1440);
    }

    public static void log(Context c, String msg) {
        try {
            SharedPreferences p = sp(c);
            String line = new SimpleDateFormat("dd HH:mm:ss", Locale.ENGLISH).format(new Date()) + " " + msg + "\n";
            String all = p.getString("log", "") + line;
            if (all.length() > 3000) all = all.substring(all.length() - 3000);
            p.edit().putString("log", all).apply();
        } catch (Exception e) { }
    }

    public static long nextFire(Context c, int id) {
        return sp(c).getLong("next_" + id, 0L);
    }

    static PendingIntent ringPI(Context c, int id, int code, String tone) {
        Intent i = new Intent(c, RingService.class);
        i.putExtra("id", id);
        i.putExtra("tone", tone == null ? "" : tone);
        return PendingIntent.getForegroundService(c, code, i,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    static PendingIntent ringActPI(Context c, int id, int code, String tone) {
        Intent i = new Intent(c, RingActivity.class);
        i.putExtra("id", id);
        i.putExtra("tone", tone == null ? "" : tone);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        return PendingIntent.getActivity(c, code, i,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    public static void rescheduleOne(Context c, int id) {
        for (A a : load(c)) if (a.id == id) schedule(c, a);
    }

    static PendingIntent opK(Context c, int id, int k) {
        Intent i = new Intent(c, AlarmReceiver.class);
        i.putExtra("id", id);
        return PendingIntent.getBroadcast(c, id * 100 + k, i,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    static PendingIntent op(Context c, int id, boolean snooze) {
        Intent i = new Intent(c, AlarmReceiver.class);
        i.putExtra("id", id);
        return PendingIntent.getBroadcast(c, snooze ? 100000 + id : id, i,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    static PendingIntent show(Context c, int id) {
        return PendingIntent.getActivity(c, id, new Intent(c, MainActivity.class),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    public static boolean schedule(Context c, A a) {
        try {
            AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
            am.cancel(op(c, a.id, false));
            am.cancel(ringPI(c, a.id, a.id, ""));
            am.cancel(ringActPI(c, a.id, a.id, ""));
            for (int k = 1; k <= 6; k++) {
                am.cancel(opK(c, a.id, k));
                am.cancel(ringPI(c, a.id, a.id * 100 + k, ""));
            }
            if (!a.on) {
                sp(c).edit().remove("next_" + a.id).apply();
                return true;
            }
            long now = System.currentTimeMillis();
            LocalDate today = LocalDate.now();
            List<Long> times = new ArrayList<>();
            for (int d = 0; d < 21 && times.size() < 7; d++) {
                LocalDate dt = today.plusDays(d);
                if (!dayOn(a, dt)) continue;
                int m = eff(a, dt.toEpochDay());
                long t = dt.atTime(m / 60, m % 60).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli();
                if (t > now + 1000) times.add(t);
            }
            if (times.isEmpty()) return true;

            long first = times.get(0);
            am.setAlarmClock(new AlarmManager.AlarmClockInfo(first, show(c, a.id)), op(c, a.id, false));
            sp(c).edit().putLong("next_" + a.id, first).apply();

            for (int k = 1; k < times.size(); k++) {
                try {
                    am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, times.get(k), opK(c, a.id, k));
                } catch (SecurityException e) { }
            }
            log(c, "جدولة " + times.size() + " مواعيد للمنبّه " + a.id + "، القادم "
                    + new SimpleDateFormat("dd HH:mm", Locale.ENGLISH).format(new Date(first)));
            return true;
        } catch (SecurityException e) {
            return false;
        }
    }

    public static void snooze(Context c, int id, int minutes) {
        try {
            AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
            long t = System.currentTimeMillis() + minutes * 60000L;
            am.setAlarmClock(new AlarmManager.AlarmClockInfo(t, show(c, id)), op(c, id, true));
        } catch (SecurityException e) { }
    }

    public static void cancel(Context c, int id) {
        sp(c).edit().remove("next_" + id).apply();
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        am.cancel(op(c, id, false));
        am.cancel(op(c, id, true));
        for (int k = 1; k <= 6; k++) {
            am.cancel(opK(c, id, k));
            am.cancel(ringPI(c, id, id * 100 + k, ""));
        }
        am.cancel(ringPI(c, id, id, ""));
        am.cancel(ringActPI(c, id, id, ""));
    }
}
