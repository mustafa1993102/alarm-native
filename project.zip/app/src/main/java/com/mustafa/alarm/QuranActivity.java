package com.mustafa.alarm;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import org.json.JSONArray;
import org.json.JSONObject;

public class QuranActivity extends Activity {
    static final int BG = 0xFF0E1428, CARD = 0xFF182047, TXT = 0xFFEEF1FB,
            MUTED = 0xFF8992BE, SUN = 0xFFF5A25C, MINT = 0xFF5FE3C4, BTN = 0xFF212A56;

    static final String DUA_KHATM =
        "اللَّهُمَّ ارْحَمْنِي بِالْقُرْآنِ، وَاجْعَلْهُ لِي إِمَامًا وَنُورًا وَهُدًى وَرَحْمَةً، اللَّهُمَّ ذَكِّرْنِي مِنْهُ مَا نُسِّيتُ، وَعَلِّمْنِي مِنْهُ مَا جَهِلْتُ، وَارْزُقْنِي تِلَاوَتَهُ آنَاءَ اللَّيْلِ وَأَطْرَافَ النَّهَارِ، وَاجْعَلْهُ لِي حُجَّةً يَا رَبَّ الْعَالَمِينَ.\n\n" +
        "اللَّهُمَّ اجْعَلِ الْقُرْآنَ الْعَظِيمَ رَبِيعَ قَلْبِي، وَنُورَ صَدْرِي، وَجَلَاءَ حُزْنِي، وَذَهَابَ هَمِّي وَغَمِّي.\n\n" +
        "اللَّهُمَّ إِنَّا نَسْأَلُكَ أَنْ تَرْفَعَ بِهِ ذِكْرَنَا، وَتُكَفِّرَ بِهِ سَيِّئَاتِنَا، وَتَغْفِرَ بِهِ ذُنُوبَنَا، وَتُصْلِحَ بِهِ شَأْنَنَا، وَتَجْمَعَ بِهِ شَمْلَنَا، وَتُقَرِّبَ بِهِ أَرْحَامَنَا، وَتَتَقَبَّلَهُ مِنَّا.\n\n" +
        "اللَّهُمَّ اجْعَلْنَا مِنْ أَهْلِ الْقُرْآنِ الَّذِينَ هُمْ أَهْلُكَ وَخَاصَّتُكَ، وَتَوَفَّنَا عَلَيْهِ، وَاحْشُرْنَا فِي زُمْرَةِ نَبِيِّكَ مُحَمَّدٍ صَلَّى اللَّهُ عَلَيْهِ وَسَلَّمَ، وَصَلَّى اللَّهُ عَلَيْهِ وَعَلَى آلِهِ وَصَحْبِهِ وَسَلَّمَ، وَالْحَمْدُ لِلَّهِ رَبِّ الْعَالَمِينَ.";

    LinearLayout list;
    TextView status;

    int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(BG);
        sv.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        sv.setFitsSystemWindows(true);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(22), dp(16), dp(30));

        TextView title = new TextView(this);
        title.setText("المصحف الشريف");
        title.setTextSize(22);
        title.setTypeface(null, Typeface.BOLD);
        title.setTextColor(TXT);
        title.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(-1, -2);
        tp.bottomMargin = dp(14);
        root.addView(title, tp);

        Button duaBtn = new Button(this);
        duaBtn.setText("🤲 دعاء ختم القرآن");
        duaBtn.setAllCaps(false);
        duaBtn.setTextColor(SUN);
        GradientDrawable dg = new GradientDrawable();
        dg.setColor(CARD);
        dg.setCornerRadius(dp(14));
        duaBtn.setBackground(dg);
        duaBtn.setOnClickListener(v -> showDua());
        LinearLayout.LayoutParams dp2 = new LinearLayout.LayoutParams(-1, dp(54));
        dp2.bottomMargin = dp(16);
        root.addView(duaBtn, dp2);

        status = new TextView(this);
        status.setText("جارٍ تحميل قائمة السور...");
        status.setTextColor(MUTED);
        status.setGravity(Gravity.CENTER);
        status.setPadding(0, dp(20), 0, dp(20));
        root.addView(status);

        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        root.addView(list);

        sv.addView(root);
        setContentView(sv);

        loadSurahs();
    }

    void showDua() {
        TextView t = new TextView(this);
        t.setText(DUA_KHATM);
        t.setTextSize(16);
        t.setLineSpacing(dp(5), 1f);
        t.setPadding(dp(20), dp(16), dp(20), dp(10));
        t.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        ScrollView s = new ScrollView(this);
        s.addView(t);
        new AlertDialog.Builder(this)
                .setTitle("دعاء ختم القرآن الكريم")
                .setView(s)
                .setPositiveButton("إغلاق", null)
                .show();
    }

    void loadSurahs() {
        Net.get("https://api.alquran.cloud/v1/surah", (json, err) -> runOnUiThread(() -> {
            if (err != null || json == null) {
                status.setText("تعذّر الاتصال بالإنترنت. اضغط للمحاولة مجددًا");
                status.setOnClickListener(v -> { status.setText("جارٍ تحميل قائمة السور..."); loadSurahs(); });
                return;
            }
            try {
                JSONObject o = new JSONObject(json);
                JSONArray data = o.getJSONArray("data");
                status.setVisibility(View.GONE);
                list.removeAllViews();
                for (int i = 0; i < data.length(); i++) {
                    JSONObject s = data.getJSONObject(i);
                    list.addView(row(s.getInt("number"), s.getString("name"),
                            s.getString("englishName"), s.getInt("numberOfAyahs"),
                            s.getString("revelationType")));
                }
            } catch (Exception e) {
                status.setText("تعذّرت قراءة البيانات، أعد المحاولة");
            }
        }));
    }

    View row(int num, String arName, String enName, int ayahCount, String type) {
        LinearLayout r = new LinearLayout(this);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(dp(14), dp(13), dp(14), dp(13));
        GradientDrawable g = new GradientDrawable();
        g.setColor(CARD);
        g.setCornerRadius(dp(14));
        r.setBackground(g);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.bottomMargin = dp(8);
        r.setLayoutParams(lp);

        TextView numT = new TextView(this);
        numT.setText(String.valueOf(num));
        numT.setTextColor(SUN);
        numT.setTypeface(null, Typeface.BOLD);
        numT.setTextSize(15);
        LinearLayout.LayoutParams ntp = new LinearLayout.LayoutParams(dp(34), -2);
        r.addView(numT, ntp);

        LinearLayout mid = new LinearLayout(this);
        mid.setOrientation(LinearLayout.VERTICAL);
        TextView name = new TextView(this);
        name.setText(arName);
        name.setTextColor(TXT);
        name.setTextSize(18);
        name.setTypeface(null, Typeface.BOLD);
        mid.addView(name);
        TextView sub = new TextView(this);
        sub.setText((type.equalsIgnoreCase("Meccan") ? "مكّية" : "مدنيّة") + " • " + ayahCount + " آية");
        sub.setTextColor(MUTED);
        sub.setTextSize(12);
        mid.addView(sub);
        r.addView(mid, new LinearLayout.LayoutParams(0, -2, 1f));

        r.setOnClickListener(v -> {
            Intent it = new Intent(this, SurahReadActivity.class);
            it.putExtra("num", num);
            it.putExtra("name", arName);
            startActivity(it);
        });
        return r;
    }
}
