package com.mustafa.alarm;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;

/** مركز المصحف: فتح الصفحات الأصلية (بلا إنترنت)، الانتقال إلى آخر توقف، والبحث في الآيات (يحتاج إنترنت فقط للبحث). */
public class QuranActivity extends Activity {
    static final int BG = 0xFF0E1428, CARD = 0xFF182047, TXT = 0xFFEEF1FB,
            MUTED = 0xFF8992BE, SUN = 0xFFF5A25C, MINT = 0xFF5FE3C4, BTN = 0xFF212A56;

    static final String DUA_KHATM =
        "اللَّهُمَّ ارْحَمْنِي بِالْقُرْآنِ، وَاجْعَلْهُ لِي إِمَامًا وَنُورًا وَهُدًى وَرَحْمَةً، اللَّهُمَّ ذَكِّرْنِي مِنْهُ مَا نُسِّيتُ، وَعَلِّمْنِي مِنْهُ مَا جَهِلْتُ، وَارْزُقْنِي تِلَاوَتَهُ آنَاءَ اللَّيْلِ وَأَطْرَافَ النَّهَارِ، وَاجْعَلْهُ لِي حُجَّةً يَا رَبَّ الْعَالَمِينَ.\n\n" +
        "اللَّهُمَّ اجْعَلِ الْقُرْآنَ الْعَظِيمَ رَبِيعَ قَلْبِي، وَنُورَ صَدْرِي، وَجَلَاءَ حُزْنِي، وَذَهَابَ هَمِّي وَغَمِّي.\n\n" +
        "اللَّهُمَّ إِنَّا نَسْأَلُكَ أَنْ تَرْفَعَ بِهِ ذِكْرَنَا، وَتُكَفِّرَ بِهِ سَيِّئَاتِنَا، وَتَغْفِرَ بِهِ ذُنُوبَنَا، وَتُصْلِحَ بِهِ شَأْنَنَا، وَتَجْمَعَ بِهِ شَمْلَنَا، وَتُقَرِّبَ بِهِ أَرْحَامَنَا، وَتَتَقَبَّلَهُ مِنَّا.\n\n" +
        "اللَّهُمَّ اجْعَلْنَا مِنْ أَهْلِ الْقُرْآنِ الَّذِينَ هُمْ أَهْلُكَ وَخَاصَّتُكَ، وَتَوَفَّنَا عَلَيْهِ، وَاحْشُرْنَا فِي زُمْرَةِ نَبِيِّكَ مُحَمَّدٍ صَلَّى اللَّهُ عَلَيْهِ وَسَلَّمَ، وَالْحَمْدُ لِلَّهِ رَبِّ الْعَالَمِينَ.";

    LinearLayout results;
    TextView searchStatus;

    int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(BG);
        sv.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        sv.setFitsSystemWindows(true);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(22), dp(16), dp(30));

        TextView title = new TextView(this);
        title.setText("المصحف الشريف");
        title.setTextSize(22);
        title.setTypeface(null, Typeface.BOLD);
        title.setTextColor(TXT);
        title.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(-1, -2);
        tp.bottomMargin = dp(16);
        root.addView(title, tp);

        SharedPreferences msp = getSharedPreferences("mushafpages", 0);
        if (msp.contains("lastPage")) {
            Button cont = mkBtn("↩️ متابعة من آخر توقف", MINT, 0xFF06251F);
            cont.setOnClickListener(v -> {
                Intent it = new Intent(this, MushafPagesActivity.class);
                it.putExtra("page", msp.getInt("lastPage", 0));
                startActivity(it);
            });
            root.addView(cont, lp(54, 12));
        }

        Button openBtn = mkBtn("📄 فتح المصحف", CARD, SUN);
        openBtn.setOnClickListener(v -> startActivity(new Intent(this, MushafPagesActivity.class)));
        root.addView(openBtn, lp(54, 12));

        Button indexBtn = mkBtn("📑 فهرس السور", CARD, MINT);
        indexBtn.setOnClickListener(v -> startActivity(new Intent(this, SurahIndexActivity.class)));
        root.addView(indexBtn, lp(54, 12));

        Button duaBtn = mkBtn("🤲 دعاء ختم القرآن", CARD, SUN);
        duaBtn.setOnClickListener(v -> showDua());
        root.addView(duaBtn, lp(54, 22));

        TextView searchTitle = new TextView(this);
        searchTitle.setText("البحث في الآيات");
        searchTitle.setTextSize(16);
        searchTitle.setTypeface(null, Typeface.BOLD);
        searchTitle.setTextColor(TXT);
        root.addView(searchTitle, lp(-2, 8));

        TextView searchHint = new TextView(this);
        searchHint.setText("اكتب كلمة أو جزءًا من الآية (يحتاج إنترنت)");
        searchHint.setTextSize(12);
        searchHint.setTextColor(MUTED);
        root.addView(searchHint, lp(-2, 10));

        LinearLayout searchRow = new LinearLayout(this);
        searchRow.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        final EditText search = new EditText(this);
        search.setHint("مثال: الرحمن الرحيم");
        search.setHintTextColor(MUTED);
        search.setTextColor(TXT);
        search.setSingleLine(true);
        search.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
        search.setPadding(dp(14), dp(10), dp(14), dp(10));
        GradientDrawable sg = new GradientDrawable();
        sg.setColor(CARD);
        sg.setCornerRadius(dp(12));
        search.setBackground(sg);
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(0, dp(48), 1f);
        slp.setMarginEnd(dp(8));
        searchRow.addView(search, slp);

        Button goBtn = mkBtn("بحث", MINT, 0xFF06251F);
        goBtn.setTextSize(14);
        searchRow.addView(goBtn, new LinearLayout.LayoutParams(dp(80), dp(48)));
        root.addView(searchRow, lp(-2, 12));

        searchStatus = new TextView(this);
        searchStatus.setTextColor(MUTED);
        searchStatus.setGravity(Gravity.CENTER);
        searchStatus.setPadding(0, dp(10), 0, dp(10));
        root.addView(searchStatus);

        results = new LinearLayout(this);
        results.setOrientation(LinearLayout.VERTICAL);
        root.addView(results);

        Runnable doSearch = () -> {
            String q = search.getText().toString().trim();
            if (q.isEmpty()) return;
            runSearch(q);
        };
        goBtn.setOnClickListener(v -> doSearch.run());
        search.setOnEditorActionListener((tv, actionId, ev) -> { doSearch.run(); return true; });

        sv.addView(root);
        setContentView(sv);
    }

    LinearLayout.LayoutParams lp(int heightDp, int bottomMarginDp) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, heightDp == -2 ? -2 : dp(heightDp));
        p.bottomMargin = dp(bottomMarginDp);
        return p;
    }

    Button mkBtn(String text, int bg, int fg) {
        Button btn = new Button(this);
        btn.setText(text);
        btn.setAllCaps(false);
        btn.setTextColor(fg);
        GradientDrawable g = new GradientDrawable();
        g.setColor(bg);
        g.setCornerRadius(dp(14));
        btn.setBackground(g);
        return btn;
    }

    void showDua() {
        TextView t = new TextView(this);
        t.setText(DUA_KHATM);
        t.setTextSize(16);
        t.setLineSpacing(dp(5), 1f);
        t.setPadding(dp(20), dp(16), dp(20), dp(10));
        t.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        ScrollView s = new ScrollView(this);
        s.addView(t);
        new AlertDialog.Builder(this).setTitle("دعاء ختم القرآن الكريم").setView(s)
                .setPositiveButton("إغلاق", null).show();
    }

    void runSearch(String q) {
        results.removeAllViews();
        searchStatus.setText("جارٍ البحث...");
        String url = "https://api.alquran.cloud/v1/search/" + android.net.Uri.encode(q) + "/all/quran-uthmani";
        Net.get(url, (json, err) -> runOnUiThread(() -> {
            if (err != null || json == null) {
                searchStatus.setText("تعذّر البحث. تحقق من الإنترنت");
                return;
            }
            try {
                JSONObject o = new JSONObject(json);
                if (o.optInt("code", 200) != 200 || !o.has("data")) {
                    searchStatus.setText("لا توجد نتائج لـ \"" + q + "\"");
                    return;
                }
                JSONArray matches = o.getJSONObject("data").getJSONArray("matches");
                if (matches.length() == 0) {
                    searchStatus.setText("لا توجد نتائج لـ \"" + q + "\"");
                    return;
                }
                searchStatus.setText(matches.length() + " نتيجة — اضغط على أي نتيجة لعرضها كاملة");
                int show = Math.min(matches.length(), 30);
                for (int i = 0; i < show; i++) {
                    JSONObject m = matches.getJSONObject(i);
                    String text = m.getString("text");
                    JSONObject surahObj = m.getJSONObject("surah");
                    String surahName = surahObj.getString("name");
                    int surahNum = surahObj.getInt("number");
                    int ayahNum = m.getInt("numberInSurah");
                    results.addView(resultRow(text, surahName, surahNum, ayahNum));
                }
            } catch (Exception e) {
                searchStatus.setText("تعذّرت قراءة نتائج البحث");
            }
        }));
    }

    View resultRow(String text, String surahName, int surahNum, int ayahNum) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.VERTICAL);
        r.setPadding(dp(14), dp(12), dp(14), dp(12));
        GradientDrawable g = new GradientDrawable();
        g.setColor(CARD);
        g.setCornerRadius(dp(14));
        r.setBackground(g);
        LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(-1, -2);
        rlp.bottomMargin = dp(8);
        r.setLayoutParams(rlp);

        TextView head = new TextView(this);
        head.setText("سورة " + surahName + " • آية " + ayahNum);
        head.setTextColor(SUN);
        head.setTextSize(12.5f);
        head.setTypeface(null, Typeface.BOLD);
        r.addView(head);

        TextView body = new TextView(this);
        body.setText(text);
        body.setTextColor(TXT);
        body.setTextSize(17);
        body.setPadding(0, dp(6), 0, 0);
        r.addView(body);

        r.setOnClickListener(v -> {
            new AlertDialog.Builder(this)
                    .setTitle("سورة " + surahName + " • آية " + ayahNum)
                    .setMessage(text + "\n\nالانتقال إلى صفحة بداية السورة في المصحف الأصلي (قد تحتاج تمرير بضع صفحات للوصول للآية بدقة).")
                    .setPositiveButton("فتح صفحة السورة", (d, w) -> {
                        Intent it = new Intent(this, MushafPagesActivity.class);
                        it.putExtra("page", SurahPageIndex.fileIndexForSurah(surahNum));
                        startActivity(it);
                    })
                    .setNegativeButton("إغلاق", null)
                    .show();
        });
        return r;
    }
}
