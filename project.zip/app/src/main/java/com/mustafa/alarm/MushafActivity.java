package com.mustafa.alarm;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager2.widget.ViewPager2;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.HashMap;
import java.util.Map;

public class MushafActivity extends Activity {
    static final int BG = 0xFF0E1428, CARD = 0xFF182047, TXT = 0xFFEEF1FB,
            MUTED = 0xFF8992BE, SUN = 0xFFF5A25C, MINT = 0xFF5FE3C4;

    static final String DUA_KHATM =
        "دعاء ختم القرآن الكريم\n\n" +
        "اللَّهُمَّ ارْحَمْنِي بِالْقُرْآنِ، وَاجْعَلْهُ لِي إِمَامًا وَنُورًا وَهُدًى وَرَحْمَةً، اللَّهُمَّ ذَكِّرْنِي مِنْهُ مَا نُسِّيتُ، وَعَلِّمْنِي مِنْهُ مَا جَهِلْتُ، وَارْزُقْنِي تِلَاوَتَهُ آنَاءَ اللَّيْلِ وَأَطْرَافَ النَّهَارِ، وَاجْعَلْهُ لِي حُجَّةً يَا رَبَّ الْعَالَمِينَ.\n\n" +
        "اللَّهُمَّ اجْعَلِ الْقُرْآنَ الْعَظِيمَ رَبِيعَ قَلْبِي، وَنُورَ صَدْرِي، وَجَلَاءَ حُزْنِي، وَذَهَابَ هَمِّي وَغَمِّي.\n\n" +
        "اللَّهُمَّ إِنَّا نَسْأَلُكَ أَنْ تَرْفَعَ بِهِ ذِكْرَنَا، وَتُكَفِّرَ بِهِ سَيِّئَاتِنَا، وَتَغْفِرَ بِهِ ذُنُوبَنَا، وَتُصْلِحَ بِهِ شَأْنَنَا، وَتَجْمَعَ بِهِ شَمْلَنَا، وَتُقَرِّبَ بِهِ أَرْحَامَنَا، وَتَتَقَبَّلَهُ مِنَّا.\n\n" +
        "اللَّهُمَّ اجْعَلْنَا مِنْ أَهْلِ الْقُرْآنِ الَّذِينَ هُمْ أَهْلُكَ وَخَاصَّتُكَ، وَتَوَفَّنَا عَلَيْهِ، وَاحْشُرْنَا فِي زُمْرَةِ نَبِيِّكَ مُحَمَّدٍ صَلَّى اللَّهُ عَلَيْهِ وَسَلَّمَ، وَالْحَمْدُ لِلَّهِ رَبِّ الْعَالَمِينَ.";

    ViewPager2 pager;
    TextView pageLabel, loading;
    Map<Integer, String[]> tafsirCache = new HashMap<>();
    SharedPreferences sp;

    int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        sp = getSharedPreferences("mushaf", 0);

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(BG);
        root.setFitsSystemWindows(true);

        loading = new TextView(this);
        loading.setText("جارٍ تحميل المصحف الشريف...");
        loading.setTextColor(MUTED);
        loading.setGravity(Gravity.CENTER);
        loading.setTextSize(16);
        root.addView(loading, new FrameLayout.LayoutParams(-1, -2, Gravity.CENTER));

        pager = new ViewPager2(this);
        pager.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        pager.setVisibility(View.GONE);
        root.addView(pager, new FrameLayout.LayoutParams(-1, -1));

        // شريط علوي: رقم الصفحة + زر حفظ الموضع + زر رجوع
        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(dp(12), dp(10), dp(12), dp(10));
        top.setBackgroundColor(0xCC0E1428);
        top.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        TextView back = iconBtn("✕");
        back.setOnClickListener(v -> finish());
        top.addView(back);

        pageLabel = new TextView(this);
        pageLabel.setTextColor(TXT);
        pageLabel.setTextSize(13);
        pageLabel.setGravity(Gravity.CENTER);
        top.addView(pageLabel, new LinearLayout.LayoutParams(0, -2, 1f));

        TextView mark = iconBtn("🔖");
        mark.setOnClickListener(v -> {
            sp.edit().putInt("lastPage", pager.getCurrentItem()).apply();
            Toast.makeText(this, "تم حفظ موضع التوقف", Toast.LENGTH_SHORT).show();
        });
        top.addView(mark);

        FrameLayout.LayoutParams topLp = new FrameLayout.LayoutParams(-1, -2);
        topLp.gravity = Gravity.TOP;
        root.addView(top, topLp);

        setContentView(root);

        int startSurah = getIntent().getIntExtra("surah", 0);
        int startPage = getIntent().getIntExtra("page", -1);

        MushafData.load(ok -> runOnUiThread(() -> {
            if (!ok) {
                loading.setText("تعذّر تحميل المصحف. تحقق من الإنترنت وأعد المحاولة");
                loading.setOnClickListener(v -> { loading.setText("جارٍ تحميل المصحف الشريف..."); recreate(); });
                return;
            }
            loading.setVisibility(View.GONE);
            pager.setVisibility(View.VISIBLE);
            pager.setAdapter(new PageAdapter());
            pager.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
                @Override public void onPageSelected(int pos) {
                    updateLabel(pos);
                    sp.edit().putInt("lastPage", pos).apply();
                }
            });
            int target = startPage >= 0 ? startPage
                    : startSurah > 0 ? firstPageOf(startSurah)
                    : sp.getInt("lastPage", 0);
            pager.setCurrentItem(Math.min(target, MushafData.pages.size() - 1), false);
            updateLabel(pager.getCurrentItem());
        }));
    }

    TextView iconBtn(String s) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(20);
        t.setPadding(dp(10), dp(6), dp(10), dp(6));
        t.setTextColor(TXT);
        return t;
    }

    int firstPageOf(int surahNum) {
        for (MushafData.SurahMeta m : MushafData.surahs) if (m.number == surahNum) return m.firstPage;
        return 0;
    }

    void updateLabel(int pos) {
        int total = MushafData.pages.size();
        if (pos == total - 1) { pageLabel.setText("دعاء الختم"); return; }
        MushafData.Page p = MushafData.pages.get(pos);
        String sName = null;
        for (MushafData.Block bl : p.blocks) {
            if (bl.isHeader) { sName = bl.headerName; break; }
            if (bl.surah > 0) {
                for (MushafData.SurahMeta m : MushafData.surahs) if (m.number == bl.surah) sName = m.name;
                break;
            }
        }
        pageLabel.setText((sName != null ? sName + " • " : "") + "صفحة " + (pos + 1) + " / " + (total - 1));
    }

    void showTafsir(int surah, int ayah, String ayahText) {
        String[] cached = tafsirCache.get(surah);
        if (cached != null) {
            openTafsirDialog(ayah, ayahText, cached);
            return;
        }
        Toast.makeText(this, "جارٍ تحميل التفسير...", Toast.LENGTH_SHORT).show();
        Net.get("https://cdn.jsdelivr.net/gh/spa5k/tafsir_api@main/tafsir/ar-tafsir-muyassar/" + surah + ".json",
            (json, err) -> runOnUiThread(() -> {
                if (err != null || json == null) {
                    Toast.makeText(this, "تعذّر تحميل التفسير", Toast.LENGTH_SHORT).show();
                    return;
                }
                try {
                    JSONObject o = new JSONObject(json);
                    JSONArray arr = o.getJSONArray("ayahs");
                    String[] arrS = new String[arr.length()];
                    for (int i = 0; i < arr.length(); i++) {
                        JSONObject a = arr.getJSONObject(i);
                        arrS[i] = a.has("text") ? a.getString("text") : "";
                    }
                    tafsirCache.put(surah, arrS);
                    openTafsirDialog(ayah, ayahText, arrS);
                } catch (Exception e) {
                    Toast.makeText(this, "تعذّرت قراءة التفسير", Toast.LENGTH_SHORT).show();
                }
            }));
    }

    void openTafsirDialog(int ayah, String ayahText, String[] arr) {
        String t = (ayah - 1 >= 0 && ayah - 1 < arr.length) ? arr[ayah - 1] : "لا يتوفر تفسير لهذه الآية";
        TextView tv = new TextView(this);
        tv.setText(t);
        tv.setTextSize(15);
        tv.setLineSpacing(dp(4), 1f);
        tv.setPadding(dp(18), dp(14), dp(18), dp(6));
        tv.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        ScrollView sv = new ScrollView(this);
        sv.addView(tv);
        new AlertDialog.Builder(this)
                .setTitle("تفسير الآية " + ayah)
                .setView(sv)
                .setPositiveButton("إغلاق", null)
                .show();
    }

    class PageAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
        @NonNull @Override
        public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            FrameLayout fl = new FrameLayout(parent.getContext());
            return new RecyclerView.ViewHolder(fl) {};
        }

        @Override
        public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
            FrameLayout fl = (FrameLayout) holder.itemView;
            fl.removeAllViews();
            MushafData.Page page = MushafData.pages.get(position);

            if (page.blocks.size() == 1 && page.blocks.get(0).isDua) {
                ScrollView sv = new ScrollView(MushafActivity.this);
                LinearLayout col = new LinearLayout(MushafActivity.this);
                col.setOrientation(LinearLayout.VERTICAL);
                col.setGravity(Gravity.CENTER);
                col.setPadding(dp(26), dp(90), dp(26), dp(60));
                TextView t = new TextView(MushafActivity.this);
                t.setText(DUA_KHATM);
                t.setTextColor(SUN);
                t.setTextSize(18);
                t.setLineSpacing(dp(7), 1f);
                t.setGravity(Gravity.CENTER);
                t.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
                col.addView(t);
                sv.addView(col);
                fl.addView(sv, new FrameLayout.LayoutParams(-1, -1));
                return;
            }

            ScrollView sv = new ScrollView(MushafActivity.this);
            LinearLayout col = new LinearLayout(MushafActivity.this);
            col.setOrientation(LinearLayout.VERTICAL);
            col.setPadding(dp(16), dp(64), dp(16), dp(40));
            col.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

            FlowLayout flow = new FlowLayout(MushafActivity.this);
            col.addView(flow, new LinearLayout.LayoutParams(-1, -2));

            for (MushafData.Block bl : page.blocks) {
                if (bl.isHeader) {
                    LinearLayout hdr = new LinearLayout(MushafActivity.this);
                    hdr.setOrientation(LinearLayout.VERTICAL);
                    hdr.setGravity(Gravity.CENTER);
                    GradientDrawable g = new GradientDrawable();
                    g.setColor(CARD);
                    g.setCornerRadius(dp(14));
                    g.setStroke(dp(1), 0x33F5A25C);
                    hdr.setBackground(g);
                    hdr.setPadding(dp(12), dp(12), dp(12), dp(12));
                    TextView name = new TextView(MushafActivity.this);
                    name.setText("سورة " + bl.headerName);
                    name.setTextColor(SUN);
                    name.setTypeface(null, Typeface.BOLD);
                    name.setTextSize(18);
                    name.setGravity(Gravity.CENTER);
                    hdr.addView(name);
                    if (bl.headerIsBismillah) {
                        TextView bsm = new TextView(MushafActivity.this);
                        bsm.setText("بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ");
                        bsm.setTextColor(TXT);
                        bsm.setTextSize(17);
                        bsm.setGravity(Gravity.CENTER);
                        bsm.setPadding(0, dp(6), 0, 0);
                        hdr.addView(bsm);
                    }
                    LinearLayout.LayoutParams hlp = new LinearLayout.LayoutParams(-1, -2);
                    hlp.bottomMargin = dp(14);
                    // رأس السورة هو دائمًا أول عنصر في الصفحة، فيوضع قبل الفلو مباشرة
                    col.addView(hdr, 0, hlp);
                    continue;
                }
                TextView t = new TextView(MushafActivity.this);
                final String numerals = toArabicDigits(bl.ayah);
                t.setText(bl.text + " ﴿" + numerals + "﴾");
                t.setTextColor(TXT);
                t.setTextSize(21);
                t.setPadding(dp(2), dp(2), dp(2), dp(2));
                final int fSurah = bl.surah, fAyah = bl.ayah;
                final String fText = bl.text;
                t.setOnLongClickListener(v -> { showTafsir(fSurah, fAyah, fText); return true; });
                flow.addView(t);
            }

            sv.addView(col);
            fl.addView(sv, new FrameLayout.LayoutParams(-1, -1));
        }

        @Override public int getItemCount() { return MushafData.pages.size(); }
    }

    static String toArabicDigits(int n) {
        String[] d = {"٠","١","٢","٣","٤","٥","٦","٧","٨","٩"};
        StringBuilder sb = new StringBuilder();
        for (char c : String.valueOf(n).toCharArray()) sb.append(d[c - '0']);
        return sb.toString();
    }
}
