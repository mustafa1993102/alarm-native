package com.mustafa.alarm;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class AlarmReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent in) {
        int id = in.getIntExtra("id", -1);
        for (AlarmStore.A a : AlarmStore.load(c)) {
            if (a.id == id) {
                Intent s = new Intent(c, RingService.class);
                s.putExtra("id", id);
                s.putExtra("tone", a.tone);
                c.startForegroundService(s);
                AlarmStore.schedule(c, a);
            }
        }
    }
}
