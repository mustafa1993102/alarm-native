package com.mustafa.alarm;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class AlarmReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent in) {
        int id = in.getIntExtra("id", -1);
        AlarmStore.log(c, "استقبال الموعد للمنبّه " + id);
        for (AlarmStore.A a : AlarmStore.load(c)) {
            if (a.id == id) {
                // نجدول الموعد التالي أولًا ودائمًا، حتى لو فشل تشغيل الرنين لأي سبب،
                // فلا يتوقف المنبّه عن العمل في الأيام التالية أبدًا
                try {
                    AlarmStore.schedule(c, a);
                } catch (Exception e) { AlarmStore.log(c, "فشل الجدولة: " + e); }
                try {
                    Intent s = new Intent(c, RingService.class);
                    s.putExtra("id", id);
                    s.putExtra("tone", a.tone);
                    c.startForegroundService(s);
                    AlarmStore.log(c, "تشغيل خدمة الرنين");
                } catch (Exception e) { AlarmStore.log(c, "فشل الرنين: " + e); }
            }
        }
    }
}
