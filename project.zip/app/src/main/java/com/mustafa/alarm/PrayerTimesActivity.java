package com.mustafa.alarm;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.core.app.ActivityCompat;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** أوقات الصلاة لليوم الحالي بناءً على موقع الجهاز (يحتاج إذن الموقع والإنترنت). */
public class PrayerTimesActivity extends Activity {
    static final int BG = 0xFF0E1428, CARD = 0xFF182047, TXT = 0xFFEEF1FB,
            MUTED = 0xFF8992BE, SUN = 0xFFF5A25C, MINT = 0xFF5FE3C4;

    static final String[][] NAMES = {
        {"Fajr", "الفجر"}, {"Sunrise", "الشروق"}, {"Dhuhr", "الظهر"},
        {"Asr", "العصر"}, {"Maghrib", "المغرب"}, {"Isha", "العشاء"}
    };

    LinearLayout list;
    TextView status;
    LocationManager lm;

    int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(BG);
        sv.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        sv.setFitsSystemWindows(true);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(22), dp(16), dp(30));

        TextView title = new TextView(this);
        title.setText("أوقات الصلاة");
        title.setTextSize(22);
        title.setTypeface(null, Typeface.BOLD);
        title.setTextColor(TXT);
        title.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(-1, -2);
        tp.bottomMargin = dp(4);
        root.addView(title, tp);

        TextView dateTv = new TextView(this);
        dateTv.setText(new SimpleDateFormat("EEEE d MMMM yyyy", new Locale("ar")).format(new Date()));
        dateTv.setTextSize(13);
        dateTv.setTextColor(MUTED);
        dateTv.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams dtp = new LinearLayout.LayoutParams(-1, -2);
        dtp.bottomMargin = dp(18);
        root.addView(dateTv, dtp);

        status = new TextView(this);
        status.setText("جارٍ تحديد موقعك...");
        status.setTextColor(MUTED);
        status.setGravity(Gravity.CENTER);
        status.setPadding(0, dp(20), 0, dp(20));
        root.addView(status);

        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        root.addView(list);

        sv.addView(root);
        setContentView(sv);

        startLocating();
    }

    void startLocating() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION}, 2);
            return;
        }
        getLocationAndFetch();
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        super.onRequestPermissionsResult(code, perms, results);
        if (code == 2) {
            boolean granted = results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED;
            if (granted) getLocationAndFetch();
            else {
                status.setText("يحتاج هذا القسم إذن الموقع لحساب أوقات الصلاة بدقة. اضغط للمحاولة مجددًا");
                status.setOnClickListener(v -> { status.setText("جارٍ تحديد موقعك..."); startLocating(); });
            }
        }
    }

    void getLocationAndFetch() {
        try {
            lm = (LocationManager) getSystemService(LOCATION_SERVICE);
            Location best = null;
            for (String provider : new String[]{LocationManager.NETWORK_PROVIDER, LocationManager.GPS_PROVIDER}) {
                if (lm.isProviderEnabled(provider)) {
                    Location l = lm.getLastKnownLocation(provider);
                    if (l != null && (best == null || l.getTime() > best.getTime())) best = l;
                }
            }
            if (best != null) {
                fetchTimes(best.getLatitude(), best.getLongitude());
                return;
            }
            status.setText("جارٍ الحصول على إشارة الموقع...");
            LocationListener listener = new LocationListener() {
                @Override public void onLocationChanged(Location loc) {
                    try { lm.removeUpdates(this); } catch (Exception e) { }
                    fetchTimes(loc.getLatitude(), loc.getLongitude());
                }
                @Override public void onProviderDisabled(String p) { }
                @Override public void onProviderEnabled(String p) { }
            };
            boolean any = false;
            if (lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
                lm.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 0, 0, listener);
                any = true;
            }
            if (lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, listener);
                any = true;
            }
            if (!any) {
                status.setText("خدمة الموقع مغلقة على هاتفك. فعّلها من الإعدادات ثم أعد المحاولة");
                status.setOnClickListener(v -> { status.setText("جارٍ تحديد موقعك..."); startLocating(); });
            }
        } catch (SecurityException e) {
            status.setText("تعذّر الوصول إلى إذن الموقع");
        }
    }

    void fetchTimes(double lat, double lon) {
        status.setText("جارٍ جلب أوقات الصلاة...");
        String today = new SimpleDateFormat("dd-MM-yyyy", Locale.US).format(new Date());
        String url = "https://api.aladhan.com/v1/timings/" + today
                + "?latitude=" + lat + "&longitude=" + lon + "&method=3";
        Net.get(url, (json, err) -> runOnUiThread(() -> {
            if (err != null || json == null) {
                status.setText("تعذّر الاتصال بالإنترنت لجلب الأوقات");
                return;
            }
            try {
                JSONObject o = new JSONObject(json);
                JSONObject timings = o.getJSONObject("data").getJSONObject("timings");
                status.setVisibility(View.GONE);
                list.removeAllViews();
                for (String[] n : NAMES) {
                    String raw = timings.getString(n[0]);
                    String clean = raw.length() >= 5 ? raw.substring(0, 5) : raw;
                    list.addView(row(n[1], clean));
                }
            } catch (Exception e) {
                status.setText("تعذّرت قراءة أوقات الصلاة");
            }
        }));
    }

    View row(String name, String time) {
        LinearLayout r = new LinearLayout(this);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(dp(18), dp(16), dp(18), dp(16));
        GradientDrawable g = new GradientDrawable();
        g.setColor(CARD);
        g.setCornerRadius(dp(14));
        r.setBackground(g);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.bottomMargin = dp(10);
        r.setLayoutParams(lp);

        TextView nameT = new TextView(this);
        nameT.setText(name);
        nameT.setTextColor(TXT);
        nameT.setTextSize(18);
        nameT.setTypeface(null, Typeface.BOLD);
        r.addView(nameT, new LinearLayout.LayoutParams(0, -2, 1f));

        TextView timeT = new TextView(this);
        timeT.setText(time);
        timeT.setTextColor(SUN);
        timeT.setTextSize(20);
        timeT.setTypeface(null, Typeface.BOLD);
        r.addView(timeT);

        return r;
    }
}
