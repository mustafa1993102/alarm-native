package com.mustafa.alarm;

/** بيانات السور الـ114 الثابتة (الاسم، عدد الآيات، مكّية/مدنية) — مضمّنة في التطبيق، لا تحتاج إنترنت. */
public class SurahData {
    public static class S {
        public int num; public String name; public int ayahCount; public boolean meccan;
        S(int n, String nm, int a, boolean m) { num = n; name = nm; ayahCount = a; meccan = m; }
    }

    public static final S[] ALL = {
        new S(1,"الفاتحة",7,true), new S(2,"البقرة",286,false), new S(3,"آل عمران",200,false),
        new S(4,"النساء",176,false), new S(5,"المائدة",120,false), new S(6,"الأنعام",165,true),
        new S(7,"الأعراف",206,true), new S(8,"الأنفال",75,false), new S(9,"التوبة",129,false),
        new S(10,"يونس",109,true), new S(11,"هود",123,true), new S(12,"يوسف",111,true),
        new S(13,"الرعد",43,false), new S(14,"إبراهيم",52,true), new S(15,"الحجر",99,true),
        new S(16,"النحل",128,true), new S(17,"الإسراء",111,true), new S(18,"الكهف",110,true),
        new S(19,"مريم",98,true), new S(20,"طه",135,true), new S(21,"الأنبياء",112,true),
        new S(22,"الحج",78,false), new S(23,"المؤمنون",118,true), new S(24,"النور",64,false),
        new S(25,"الفرقان",77,true), new S(26,"الشعراء",227,true), new S(27,"النمل",93,true),
        new S(28,"القصص",88,true), new S(29,"العنكبوت",69,true), new S(30,"الروم",60,true),
        new S(31,"لقمان",34,true), new S(32,"السجدة",30,true), new S(33,"الأحزاب",73,false),
        new S(34,"سبأ",54,true), new S(35,"فاطر",45,true), new S(36,"يس",83,true),
        new S(37,"الصافات",182,true), new S(38,"ص",88,true), new S(39,"الزمر",75,true),
        new S(40,"غافر",85,true), new S(41,"فصلت",54,true), new S(42,"الشورى",53,true),
        new S(43,"الزخرف",89,true), new S(44,"الدخان",59,true), new S(45,"الجاثية",37,true),
        new S(46,"الأحقاف",35,true), new S(47,"محمد",38,false), new S(48,"الفتح",29,false),
        new S(49,"الحجرات",18,false), new S(50,"ق",45,true), new S(51,"الذاريات",60,true),
        new S(52,"الطور",49,true), new S(53,"النجم",62,true), new S(54,"القمر",55,true),
        new S(55,"الرحمن",78,false), new S(56,"الواقعة",96,true), new S(57,"الحديد",29,false),
        new S(58,"المجادلة",22,false), new S(59,"الحشر",24,false), new S(60,"الممتحنة",13,false),
        new S(61,"الصف",14,false), new S(62,"الجمعة",11,false), new S(63,"المنافقون",11,false),
        new S(64,"التغابن",18,false), new S(65,"الطلاق",12,false), new S(66,"التحريم",12,false),
        new S(67,"الملك",30,true), new S(68,"القلم",52,true), new S(69,"الحاقة",52,true),
        new S(70,"المعارج",44,true), new S(71,"نوح",28,true), new S(72,"الجن",28,true),
        new S(73,"المزمل",20,true), new S(74,"المدثر",56,true), new S(75,"القيامة",40,true),
        new S(76,"الإنسان",31,false), new S(77,"المرسلات",50,true), new S(78,"النبأ",40,true),
        new S(79,"النازعات",46,true), new S(80,"عبس",42,true), new S(81,"التكوير",29,true),
        new S(82,"الانفطار",19,true), new S(83,"المطففين",36,true), new S(84,"الانشقاق",25,true),
        new S(85,"البروج",22,true), new S(86,"الطارق",17,true), new S(87,"الأعلى",19,true),
        new S(88,"الغاشية",26,true), new S(89,"الفجر",30,true), new S(90,"البلد",20,true),
        new S(91,"الشمس",15,true), new S(92,"الليل",21,true), new S(93,"الضحى",11,true),
        new S(94,"الشرح",8,true), new S(95,"التين",8,true), new S(96,"العلق",19,true),
        new S(97,"القدر",5,true), new S(98,"البينة",8,false), new S(99,"الزلزلة",8,false),
        new S(100,"العاديات",11,true), new S(101,"القارعة",11,true), new S(102,"التكاثر",8,true),
        new S(103,"العصر",3,true), new S(104,"الهمزة",9,true), new S(105,"الفيل",5,true),
        new S(106,"قريش",4,true), new S(107,"الماعون",7,true), new S(108,"الكوثر",3,true),
        new S(109,"الكافرون",6,true), new S(110,"النصر",3,false), new S(111,"المسد",5,true),
        new S(112,"الإخلاص",4,true), new S(113,"الفلق",5,true), new S(114,"الناس",6,true),
    };
}
