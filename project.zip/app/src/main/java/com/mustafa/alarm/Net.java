package com.mustafa.alarm;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class Net {
    public interface Cb { void done(String json, Exception err); }

    public static void get(String urlStr, Cb cb) {
        new Thread(() -> {
            try {
                URL u = new URL(urlStr);
                HttpURLConnection c = (HttpURLConnection) u.openConnection();
                c.setConnectTimeout(12000);
                c.setReadTimeout(15000);
                c.setRequestMethod("GET");
                BufferedReader r = new BufferedReader(new InputStreamReader(c.getInputStream(), StandardCharsets.UTF_8));
                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = r.readLine()) != null) sb.append(line);
                r.close();
                c.disconnect();
                cb.done(sb.toString(), null);
            } catch (Exception e) {
                cb.done(null, e);
            }
        }).start();
    }
}
