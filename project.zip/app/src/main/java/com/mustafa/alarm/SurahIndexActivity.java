package com.mustafa.alarm;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;

/** فهرس السور: يفتح مباشرة على صفحة بداية السورة الحقيقية ضمن صور المصحف الأصلية. */
public class SurahIndexActivity extends Activity {
    static final int BG = 0xFF0E1428, CARD = 0xFF182047, TXT = 0xFFEEF1FB,
            MUTED = 0xFF8992BE, SUN = 0xFFF5A25C, MINT = 0xFF5FE3C4;

    static class S { int num; String name, enName, type; int ayahCount; }
    List<S> all = new ArrayList<>();
    LinearLayout list;
    TextView status;
    String filter = "";

    int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(BG);
        sv.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        sv.setFitsSystemWindows(true);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(22), dp(16), dp(30));

        TextView title = new TextView(this);
        title.setText("فهرس السور");
        title.setTextSize(22);
        title.setTypeface(null, Typeface.BOLD);
        title.setTextColor(TXT);
        title.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(-1, -2);
        tp.bottomMargin = dp(6);
        root.addView(title, tp);

        TextView hint = new TextView(this);
        hint.setText("اضغط على أي سورة للانتقال إلى صفحتها الحقيقية في المصحف");
        hint.setTextSize(12);
        hint.setTextColor(MUTED);
        hint.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(-1, -2);
        hp.bottomMargin = dp(14);
        root.addView(hint, hp);

        EditText search = new EditText(this);
        search.setHint("ابحث عن اسم السورة...");
        search.setHintTextColor(MUTED);
        search.setTextColor(TXT);
        search.setPadding(dp(16), dp(12), dp(16), dp(12));
        search.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        GradientDrawable sg = new GradientDrawable();
        sg.setColor(CARD);
        sg.setCornerRadius(dp(14));
        search.setBackground(sg);
        search.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int b2, int c) {}
            public void onTextChanged(CharSequence s, int a, int b2, int c) { filter = s.toString().trim(); renderList(); }
            public void afterTextChanged(Editable s) {}
        });
        LinearLayout.LayoutParams sp2 = new LinearLayout.LayoutParams(-1, -2);
        sp2.bottomMargin = dp(16);
        root.addView(search, sp2);

        status = new TextView(this);
        status.setText("جارٍ تحميل قائمة السور...");
        status.setTextColor(MUTED);
        status.setGravity(Gravity.CENTER);
        status.setPadding(0, dp(20), 0, dp(20));
        root.addView(status);

        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        root.addView(list);

        sv.addView(root);
        setContentView(sv);

        loadSurahs();
    }

    void loadSurahs() {
        Net.get("https://api.alquran.cloud/v1/surah", (json, err) -> runOnUiThread(() -> {
            if (err != null || json == null) {
                status.setText("تعذّر الاتصال بالإنترنت. اضغط للمحاولة مجددًا");
                status.setOnClickListener(v -> { status.setText("جارٍ تحميل قائمة السور..."); loadSurahs(); });
                return;
            }
            try {
                JSONObject o = new JSONObject(json);
                JSONArray data = o.getJSONArray("data");
                all.clear();
                for (int i = 0; i < data.length(); i++) {
                    JSONObject j = data.getJSONObject(i);
                    S s = new S();
                    s.num = j.getInt("number");
                    s.name = j.getString("name");
                    s.enName = j.getString("englishName");
                    s.type = j.getString("revelationType");
                    s.ayahCount = j.getInt("numberOfAyahs");
                    all.add(s);
                }
                status.setVisibility(View.GONE);
                renderList();
            } catch (Exception e) {
                status.setText("تعذّرت قراءة البيانات، أعد المحاولة");
            }
        }));
    }

    void renderList() {
        list.removeAllViews();
        String f = filter.trim();
        for (S s : all) {
            if (!f.isEmpty() && !s.name.contains(f) && !s.enName.toLowerCase().contains(f.toLowerCase())) continue;
            list.addView(row(s));
        }
    }

    View row(S s) {
        LinearLayout r = new LinearLayout(this);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(dp(14), dp(13), dp(14), dp(13));
        GradientDrawable g = new GradientDrawable();
        g.setColor(CARD);
        g.setCornerRadius(dp(14));
        r.setBackground(g);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.bottomMargin = dp(8);
        r.setLayoutParams(lp);

        TextView numT = new TextView(this);
        numT.setText(String.valueOf(s.num));
        numT.setTextColor(SUN);
        numT.setTypeface(null, Typeface.BOLD);
        numT.setTextSize(15);
        r.addView(numT, new LinearLayout.LayoutParams(dp(34), -2));

        LinearLayout mid = new LinearLayout(this);
        mid.setOrientation(LinearLayout.VERTICAL);
        TextView name = new TextView(this);
        name.setText(s.name);
        name.setTextColor(TXT);
        name.setTextSize(18);
        name.setTypeface(null, Typeface.BOLD);
        mid.addView(name);
        TextView sub = new TextView(this);
        sub.setText((s.type.equalsIgnoreCase("Meccan") ? "مكّية" : "مدنيّة") + " • " + s.ayahCount + " آية");
        sub.setTextColor(MUTED);
        sub.setTextSize(12);
        mid.addView(sub);
        r.addView(mid, new LinearLayout.LayoutParams(0, -2, 1f));

        TextView pageT = new TextView(this);
        int fi = SurahPageIndex.fileIndexForSurah(s.num);
        pageT.setText("ص " + (fi + 1));
        pageT.setTextColor(MINT);
        pageT.setTextSize(12.5f);
        r.addView(pageT);

        r.setOnClickListener(v -> {
            Intent it = new Intent(this, MushafPagesActivity.class);
            it.putExtra("page", fi);
            startActivity(it);
        });
        return r;
    }
}
