package com.mustafa.alarm;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent i) {
        for (AlarmStore.A a : AlarmStore.load(c)) AlarmStore.schedule(c, a);

        boolean hourlyOn = c.getSharedPreferences("dhikr", 0).getBoolean("hourlyOn", false);
        if (hourlyOn) {
            android.app.AlarmManager am = (android.app.AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
            long first = System.currentTimeMillis() + 60 * 60 * 1000L;
            am.setInexactRepeating(android.app.AlarmManager.RTC, first,
                    android.app.AlarmManager.INTERVAL_HOUR, AdhkarActivity.dhikrPendingIntent(c));
        }
    }
}
