package com.mustafa.alarm;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent i) {
        for (AlarmStore.A a : AlarmStore.load(c)) AlarmStore.schedule(c, a);
    }
}
