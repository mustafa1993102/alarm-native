package com.mustafa.alarm;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.VibrationEffect;
import android.os.Vibrator;

public class RingService extends Service {
    MediaPlayer mp;
    Vibrator vib;
    PowerManager.WakeLock wl;
    Handler h = new Handler(Looper.getMainLooper());

    @Override
    public IBinder onBind(Intent i) { return null; }

    @Override
    public int onStartCommand(Intent in, int flags, int startId) {
        if (in == null) { stopSelf(); return START_NOT_STICKY; }
        String act = in.getAction();
        int id = in.getIntExtra("id", 0);
        if ("STOP".equals(act)) { cleanup(); stopSelf(); return START_NOT_STICKY; }
        if ("SNOOZE".equals(act)) {
            AlarmStore.snooze(this, id, 5);
            cleanup(); stopSelf();
            return START_NOT_STICKY;
        }

        NotificationManager nm = getSystemService(NotificationManager.class);
        NotificationChannel ch = new NotificationChannel("ring", "المنبّه", NotificationManager.IMPORTANCE_HIGH);
        ch.setSound(null, null);
        ch.enableVibration(false);
        ch.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
        nm.createNotificationChannel(ch);

        Intent ri = new Intent(this, RingActivity.class);
        ri.putExtra("id", id);
        ri.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent full = PendingIntent.getActivity(this, 0, ri,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent stop = PendingIntent.getService(this, 1,
                new Intent(this, RingService.class).setAction("STOP").putExtra("id", id),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent snz = PendingIntent.getService(this, 2,
                new Intent(this, RingService.class).setAction("SNOOZE").putExtra("id", id),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

        Notification n = new Notification.Builder(this, "ring")
                .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentTitle("المنبّه يرنّ")
                .setContentText("اضغط للإيقاف أو الغفوة")
                .setCategory(Notification.CATEGORY_ALARM)
                .setOngoing(true)
                .setFullScreenIntent(full, true)
                .setContentIntent(full)
                .addAction(0, "إيقاف", stop)
                .addAction(0, "غفوة 5 د", snz)
                .build();
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
        } else {
            startForeground(1, n);
        }

        PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
        wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "alarm:ring");
        wl.acquire(95000);

        play(in.getStringExtra("tone"));
        h.postDelayed(() -> { cleanup(); stopSelf(); }, 90000);
        return START_NOT_STICKY;
    }

    void play(String tone) {
        try {
            Uri u = null;
            if (tone != null && !tone.isEmpty()) u = Uri.parse(tone);
            if (u == null) u = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
            if (u == null) u = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE);
            mp = new MediaPlayer();
            mp.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build());
            mp.setDataSource(this, u);
            mp.setLooping(true);
            mp.prepare();
            mp.start();
        } catch (Exception e) {
            try {
                Uri u2 = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE);
                mp = new MediaPlayer();
                mp.setDataSource(this, u2);
                mp.setLooping(true);
                mp.prepare();
                mp.start();
            } catch (Exception e2) { }
        }
        try {
            vib = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
            vib.vibrate(VibrationEffect.createWaveform(new long[]{0, 600, 400}, 0));
        } catch (Exception e) { }
    }

    void cleanup() {
        h.removeCallbacksAndMessages(null);
        try { if (mp != null) { mp.stop(); mp.release(); } } catch (Exception e) { }
        mp = null;
        try { if (vib != null) vib.cancel(); } catch (Exception e) { }
        try { if (wl != null && wl.isHeld()) wl.release(); } catch (Exception e) { }
        stopForeground(true);
        final RingActivity r = RingActivity.cur;
        if (r != null) r.runOnUiThread(() -> r.finish());
    }

    @Override
    public void onDestroy() {
        cleanup();
        super.onDestroy();
    }
}
