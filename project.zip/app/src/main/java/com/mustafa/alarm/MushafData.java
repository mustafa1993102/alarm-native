package com.mustafa.alarm;

import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;

/** تحميل القرآن كاملًا مرة واحدة وتقسيمه إلى صفحات على طريقة المصحف. */
public class MushafData {
    public static class Block {
        public boolean isHeader;
        public boolean isDua;
        public String headerName;
        public boolean headerIsBismillah;
        public int surah, ayah;
        public String text;
    }
    public static class Page {
        public List<Block> blocks = new ArrayList<>();
    }
    public static class SurahMeta {
        public int number;
        public String name, englishName, type;
        public int ayahCount;
        public int firstPage;
    }

    public static List<Page> pages;
    public static List<SurahMeta> surahs;
    static final int CHARS_PER_PAGE = 620;

    public interface Cb { void done(boolean ok); }

    public static void load(Cb cb) {
        if (pages != null) { cb.done(true); return; }
        Net.get("https://api.alquran.cloud/v1/quran/quran-uthmani", (json, err) -> {
            if (err != null || json == null) { cb.done(false); return; }
            try {
                build(json);
                cb.done(true);
            } catch (Exception e) {
                cb.done(false);
            }
        });
    }

    static void build(String json) throws Exception {
        JSONObject root = new JSONObject(json);
        JSONArray surahArr = root.getJSONObject("data").getJSONArray("surahs");
        pages = new ArrayList<>();
        surahs = new ArrayList<>();

        Page cur = new Page();
        int curChars = 0;

        for (int si = 0; si < surahArr.length(); si++) {
            JSONObject s = surahArr.getJSONObject(si);
            int num = s.getInt("number");
            String name = s.getString("name");
            String enName = s.getString("englishName");
            String type = s.getString("revelationType");
            JSONArray ayahs = s.getJSONArray("ayahs");

            SurahMeta meta = new SurahMeta();
            meta.number = num; meta.name = name; meta.englishName = enName;
            meta.type = type; meta.ayahCount = ayahs.length();

            // سورة جديدة تبدأ في صفحة جديدة إن كانت الحالية غير فارغة
            if (!cur.blocks.isEmpty()) {
                pages.add(cur);
                cur = new Page();
                curChars = 0;
            }
            meta.firstPage = pages.size();
            surahs.add(meta);

            Block header = new Block();
            header.isHeader = true;
            header.headerName = name;
            header.headerIsBismillah = num != 1 && num != 9;
            cur.blocks.add(header);
            curChars += 40;

            for (int ai = 0; ai < ayahs.length(); ai++) {
                JSONObject a = ayahs.getJSONObject(ai);
                String text = a.getString("text");
                int ayahNum = a.getInt("numberInSurah");
                if (num != 1 && ayahNum == 1 && text.startsWith("بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ")) {
                    // محذوفة لأنها تُعرض كترويسة منفصلة أصلًا ضمن أغلب الإصدارات؛ تُترك كما وردت من المصدر
                }
                Block b = new Block();
                b.surah = num; b.ayah = ayahNum; b.text = text;
                if (curChars + text.length() > CHARS_PER_PAGE && !cur.blocks.isEmpty()) {
                    pages.add(cur);
                    cur = new Page();
                    curChars = 0;
                }
                cur.blocks.add(b);
                curChars += text.length() + 6;
            }
        }
        if (!cur.blocks.isEmpty()) pages.add(cur);

        Page duaPage = new Page();
        Block dua = new Block();
        dua.isDua = true;
        duaPage.blocks.add(dua);
        pages.add(duaPage);
    }
}
