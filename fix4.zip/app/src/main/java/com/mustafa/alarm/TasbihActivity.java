package com.mustafa.alarm;

import android.app.Activity;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class TasbihActivity extends Activity {
    static final int BG = 0xFF0E1428, CARD = 0xFF182047, TXT = 0xFFEEF1FB,
            MUTED = 0xFF8992BE, SUN = 0xFFF5A25C, MINT = 0xFF5FE3C4, RED = 0xFFF2685C, BTN = 0xFF212A56;
    static final String[] PHRASES = {"سبحان الله", "الحمد لله", "الله أكبر", "لا إله إلا الله", "أستغفر الله"};
    static final int[] TARGETS = {33, 99, 100};

    SharedPreferences sp;
    int phraseIdx = 0, target = 33, count = 0;
    TextView countTv, phraseTv, targetTv;
    Vibrator vib;

    int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        sp = getSharedPreferences("tasbih", 0);
        vib = (Vibrator) getSystemService(VIBRATOR_SERVICE);
        phraseIdx = sp.getInt("phraseIdx", 0);
        target = sp.getInt("target", 33);
        count = sp.getInt("count_" + phraseIdx, 0);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(dp(24), dp(24), dp(24), dp(24));
        root.setFitsSystemWindows(true);

        TextView title = new TextView(this);
        title.setText("المسبحة الإلكترونية");
        title.setTextSize(22);
        title.setTypeface(null, Typeface.BOLD);
        title.setTextColor(TXT);
        title.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(-1, -2);
        tp.bottomMargin = dp(18);
        root.addView(title, tp);

        // اختيار الذكر
        LinearLayout phraseRow = new LinearLayout(this);
        phraseRow.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        final Button[] pBtns = new Button[PHRASES.length];
        for (int i = 0; i < PHRASES.length; i++) {
            final int idx = i;
            Button pb = mkChip(PHRASES[i], idx == phraseIdx);
            pb.setTextSize(11.5f);
            LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(0, dp(60), 1f);
            pp.setMarginEnd(dp(4));
            pb.setOnClickListener(v -> switchPhrase(idx, pBtns));
            pBtns[i] = pb;
            phraseRow.addView(pb, pp);
        }
        LinearLayout.LayoutParams prp = new LinearLayout.LayoutParams(-1, -2);
        prp.bottomMargin = dp(24);
        root.addView(phraseRow, prp);

        phraseTv = new TextView(this);
        phraseTv.setText(PHRASES[phraseIdx]);
        phraseTv.setTextSize(26);
        phraseTv.setTextColor(SUN);
        phraseTv.setTypeface(null, Typeface.BOLD);
        phraseTv.setGravity(Gravity.CENTER);
        root.addView(phraseTv);

        // دائرة العدّ
        LinearLayout circle = new LinearLayout(this);
        circle.setGravity(Gravity.CENTER);
        GradientDrawable cg = new GradientDrawable();
        cg.setShape(GradientDrawable.OVAL);
        cg.setColor(CARD);
        cg.setStroke(dp(4), 0xFFF5A25C);
        circle.setBackground(cg);
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(dp(220), dp(220));
        clp.topMargin = dp(24);
        clp.bottomMargin = dp(24);
        clp.gravity = Gravity.CENTER;

        countTv = new TextView(this);
        countTv.setText(String.valueOf(count));
        countTv.setTextSize(64);
        countTv.setTypeface(null, Typeface.BOLD);
        countTv.setTextColor(TXT);
        countTv.setGravity(Gravity.CENTER);
        circle.addView(countTv);
        circle.setOnClickListener(v -> tap());
        root.addView(circle, clp);

        targetTv = new TextView(this);
        targetTv.setText("الهدف: " + target);
        targetTv.setTextSize(14);
        targetTv.setTextColor(MUTED);
        targetTv.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams ttp = new LinearLayout.LayoutParams(-1, -2);
        ttp.bottomMargin = dp(14);
        root.addView(targetTv, ttp);

        LinearLayout targetRow = new LinearLayout(this);
        targetRow.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        for (int tgt : TARGETS) {
            Button tb = mkChip(String.valueOf(tgt), tgt == target);
            LinearLayout.LayoutParams tbp = new LinearLayout.LayoutParams(0, dp(46), 1f);
            tbp.setMarginEnd(dp(6));
            tb.setOnClickListener(v -> {
                target = tgt;
                sp.edit().putInt("target", target).apply();
                targetTv.setText("الهدف: " + target);
                refreshTargetChips(targetRow);
            });
            targetRow.addView(tb, tbp);
        }
        LinearLayout.LayoutParams trp = new LinearLayout.LayoutParams(-1, -2);
        trp.bottomMargin = dp(20);
        root.addView(targetRow, trp);

        Button reset = new Button(this);
        reset.setText("تصفير العدّاد");
        reset.setAllCaps(false);
        reset.setTextColor(RED);
        GradientDrawable rg = new GradientDrawable();
        rg.setColor(0x33F2685C);
        rg.setCornerRadius(dp(14));
        reset.setBackground(rg);
        reset.setOnClickListener(v -> {
            count = 0;
            countTv.setText("0");
            sp.edit().putInt("count_" + phraseIdx, 0).apply();
        });
        root.addView(reset, new LinearLayout.LayoutParams(-1, dp(56)));

        setContentView(root);
    }

    Button mkChip(String text, boolean active) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextColor(active ? 0xFF06251F : TXT);
        GradientDrawable g = new GradientDrawable();
        g.setColor(active ? MINT : BTN);
        g.setCornerRadius(dp(10));
        b.setBackground(g);
        return b;
    }

    void refreshTargetChips(LinearLayout row) {
        for (int i = 0; i < row.getChildCount(); i++) {
            Button b = (Button) row.getChildAt(i);
            boolean active = Integer.parseInt(b.getText().toString()) == target;
            GradientDrawable g = new GradientDrawable();
            g.setColor(active ? MINT : BTN);
            g.setCornerRadius(dp(10));
            b.setBackground(g);
            b.setTextColor(active ? 0xFF06251F : TXT);
        }
    }

    void switchPhrase(int idx, Button[] btns) {
        phraseIdx = idx;
        sp.edit().putInt("phraseIdx", idx).apply();
        count = sp.getInt("count_" + idx, 0);
        countTv.setText(String.valueOf(count));
        phraseTv.setText(PHRASES[idx]);
        for (int i = 0; i < btns.length; i++) {
            GradientDrawable g = new GradientDrawable();
            g.setColor(i == idx ? MINT : BTN);
            g.setCornerRadius(dp(10));
            btns[i].setBackground(g);
            btns[i].setTextColor(i == idx ? 0xFF06251F : TXT);
        }
    }

    void tap() {
        count++;
        countTv.setText(String.valueOf(count));
        sp.edit().putInt("count_" + phraseIdx, count).apply();
        try {
            if (count % target == 0) {
                vib.vibrate(VibrationEffect.createWaveform(new long[]{0, 120, 80, 120}, -1));
            } else {
                vib.vibrate(VibrationEffect.createOneShot(18, VibrationEffect.DEFAULT_AMPLITUDE));
            }
        } catch (Exception e) { }
    }
}
